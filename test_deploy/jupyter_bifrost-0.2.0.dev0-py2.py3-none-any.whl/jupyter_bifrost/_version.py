#!/usr/bin/env python
# coding: utf-8

# Copyright (c) John Waidhofer(waidhoferj), Jay Ahn(jahn96).
# Distributed under the terms of the Modified BSD License.

version_info = (0, 2, 0, "dev")
__version__ = ".".join(map(str, version_info))
