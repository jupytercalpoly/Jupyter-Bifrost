(self.webpackChunkjupyter_bifrost=self.webpackChunkjupyter_bifrost||[]).push([[367],{2071:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{width:t=55,height:n=56,color:r="#771C79"}=e;return i(e,["width","height","color"]),o.default.createElement("svg",{width:t,height:n,viewBox:`0 0 ${t} ${n}`,fill:"none",xmlns:"http://www.w3.org/2000/svg"},o.default.createElement("path",{d:"M15.7759 11.0173C18.7771 12.75 19.8054 16.5875 18.0726 19.5887C16.3399 22.5899 12.5024 23.6181 9.50121 21.8854C6.50005 20.1527 5.47178 16.3151 7.2045 13.314C8.93722 10.3128 12.7748 9.28456 15.7759 11.0173Z",fill:r}),o.default.createElement("circle",{cx:"21.4462",cy:"30.9299",r:"6.27472",transform:"rotate(-60 21.4462 30.9299)",fill:r}),o.default.createElement("circle",{cx:"30.8126",cy:"16.4396",r:"6.27472",transform:"rotate(-60 30.8126 16.4396)",fill:r}))}},1486:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="#6E7776",width:n=25,height:r=24}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",{width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg",style:a.style},o.default.createElement("rect",{x:"4",y:"13.5",width:"4",height:"8",fill:t,stroke:t}),o.default.createElement("rect",{x:"11",y:"8.5",width:"4",height:"13",fill:t,stroke:t}),o.default.createElement("rect",{x:"18",y:"3.5",width:"4",height:"18",fill:t,stroke:t}),o.default.createElement("path",{d:"M1 0V23.5H24.5",stroke:t}))}},7978:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="#6E7776",width:n=25,height:r=24}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",{width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg",style:a.style},o.default.createElement("path",{d:"M1 0V23.5H25",stroke:t}),o.default.createElement("path",{d:"M21.9362 16.5L21.9362 12.5M21.9362 8.5L21.9362 12.5M21.9362 12.5L18.8723 12.5M18.8723 12.5L18.8723 9.5L7.6383 9.5L7.6383 12.5M18.8723 12.5L18.8723 15.5L7.6383 15.5L7.6383 12.5M7.6383 12.5L4.57447 12.5M4.57447 12.5L4.57447 8.5M4.57447 12.5L4.57447 16.5",stroke:t}),o.default.createElement("path",{d:"M12.7447 15L12.7447 10",stroke:t}),o.default.createElement("rect",{x:"12.7447",y:"16",width:"6",height:"6.12766",transform:"rotate(-90 12.7447 16)",fill:t}))}},9873:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.chartIcons=void 0;const r=i(n(145)),o=i(n(1486)),a=i(n(5537)),s=i(n(4660)),l=i(n(7978)),c=i(n(7555)),d=i(n(6430));t.chartIcons=[{icon:o.default,mark:"bar"},{icon:r.default,mark:"point"},{icon:a.default,mark:"line"},{icon:s.default,mark:"tick"},{icon:l.default,mark:"boxplot"},{icon:c.default,mark:"errorband"},{icon:d.default,mark:"errorbar"}]},7555:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="#6E7776",width:n=24,height:r=25}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",{width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg",style:a.style},o.default.createElement("path",{d:"M0.5 0V24H24",stroke:t}),o.default.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M24 14.808L15 19.2484L7.21995 15.2756L0.976143 20.7413L0.976136 16.8505L6.77996 11.6255L15 15.8229L24 11.2332L24 14.808Z",fill:t}),o.default.createElement("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M24 9.1912L15 14.0221L7.06079 9.96807L1.00001 14.8082L0 14.2974L6.93912 8.76412L14.9999 12.8803L24 8.16992L24 9.1912Z",fill:t}))}},6430:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="#6E7776",width:n=25,height:r=25}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",{width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg",style:a.style},o.default.createElement("rect",{x:"3.55319",y:"16.3404",width:"5.10638",height:"6.12766",fill:t}),o.default.createElement("rect",{x:"10.7021",y:"13.2766",width:"5.10638",height:"9.19149",fill:t}),o.default.createElement("rect",{x:"17.8511",y:"10.2128",width:"5.10638",height:"12.2553",fill:t}),o.default.createElement("path",{d:"M1 0V24H25",stroke:t}),o.default.createElement("path",{d:"M6.10638 16.3404V13.2766M6.10638 13.2766H4.57447M6.10638 13.2766H7.6383",stroke:t}),o.default.createElement("path",{d:"M13.2553 13.2766V10.2128M13.2553 10.2128H11.7234M13.2553 10.2128H14.7872",stroke:t}),o.default.createElement("path",{d:"M20.4043 10.2128V7.14893M20.4043 7.14893H18.8723M20.4043 7.14893H21.9362",stroke:t}))}},5537:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="#6E7776",width:n=25,height:r=24}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",{width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg",style:a.style},o.default.createElement("path",{d:"M1 0V23.5H24.5",stroke:t}),o.default.createElement("circle",{cx:"4.5",cy:"19",r:"0.5",fill:t,stroke:t}),o.default.createElement("path",{d:"M4.5 19L8.5 11L16.5 10L21.5 4",stroke:t}),o.default.createElement("circle",{cx:"8.5",cy:"11",r:"0.5",fill:t,stroke:t}),o.default.createElement("circle",{cx:"21.5",cy:"4",r:"0.5",fill:t,stroke:t}),o.default.createElement("circle",{cx:"16.5",cy:"10",r:"0.5",fill:t,stroke:t}))}},145:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="#6E7776",width:n=25,height:r=24}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",{width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg",style:a.style},o.default.createElement("path",{d:"M1 0V23.5H24.5",stroke:t}),o.default.createElement("circle",{cx:"17.5",cy:"9",r:"0.5",fill:t,stroke:t}),o.default.createElement("circle",{cx:"15.5",cy:"16",r:"2.5",stroke:t}),o.default.createElement("circle",{cx:"8",cy:"7.5",r:"2",stroke:t}),o.default.createElement("circle",{cx:"19",cy:"2.5",r:"1",stroke:t}),o.default.createElement("circle",{cx:"5",cy:"17.5",r:"1",stroke:t}))}},4660:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=i(n(6271));t.default=function(e){const t=e.color||"#6E7776";return r.default.createElement("svg",{width:"25",height:"24",viewBox:"0 0 25 24",fill:"none",xmlns:"http://www.w3.org/2000/svg"},r.default.createElement("path",{d:"M1 0V23.5H24.5",stroke:t}),r.default.createElement("path",{d:"M2.5 22V16.5M4 22V16.5M5.5 22V16.5M7.5 22V16.5M10.5 22V16.5M14 22V16.5M18 22V16.5M23.5 22V16.5",stroke:t}))}},6278:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="rgba(0,0,0,0.4)",width:n=13,height:r=10}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",Object.assign({width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg"},a),o.default.createElement("path",{d:"M9.85053 4.50938C9.68417 4.50938 9.53767 4.50938 9.39095 4.50938C8.07753 4.50938 6.76367 4.52915 5.45047 4.50351C4.27715 4.48033 3.28386 3.8277 2.4587 2.67169C2.24071 2.36639 2.08539 1.99929 2.03553 1.56204C2.02052 1.43071 2.02494 1.29382 2.00155 1.1662C1.93249 0.789513 1.66928 0.555901 1.38665 0.606579C1.11461 0.655403 0.907878 0.979555 0.90545 1.36551C0.900376 2.21343 1.14087 2.93034 1.51506 3.57153C1.91617 4.25877 2.42097 4.764 2.97696 5.17591C3.0191 5.20712 3.06146 5.2371 3.10338 5.26862C3.10934 5.27325 3.11375 5.2819 3.1292 5.30292C3.07978 5.34092 3.03389 5.37708 2.98755 5.41138C2.33073 5.89776 1.74628 6.50589 1.32553 7.38101C1.06011 7.9329 0.90192 8.53794 0.904789 9.21282C0.906775 9.64575 1.14241 9.98504 1.45063 9.99956C1.74209 10.0135 2.01236 9.69488 2.02052 9.2808C2.03156 8.72428 2.21005 8.28486 2.47149 7.90138C3.06345 7.03306 3.79882 6.50929 4.62199 6.2284C4.88984 6.13693 5.17203 6.09429 5.44804 6.09182C6.87156 6.07884 8.29507 6.08595 9.71881 6.08626C9.75808 6.08626 9.79735 6.08626 9.84876 6.08626C9.84876 6.15887 9.84876 6.21388 9.84876 6.26888C9.84876 6.80316 9.8481 7.33775 9.84898 7.87203C9.84942 8.13067 9.91914 8.29043 10.0592 8.36304C10.2018 8.4369 10.324 8.3788 10.444 8.17826C10.9526 7.32724 11.4609 6.47623 11.9688 5.62459C12.1385 5.34 12.1376 5.17622 11.9686 4.89224C11.4587 4.03628 10.9495 3.1794 10.4387 2.32467C10.2966 2.08674 10.1043 2.05553 9.95819 2.23877C9.87193 2.34723 9.8503 2.49 9.8503 2.64388C9.85031 3.20412 9.85031 3.76404 9.85031 4.32428C9.85053 4.3799 9.85053 4.43491 9.85053 4.50938Z",fill:t}))}},3773:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.filterIconMap=void 0;const r=i(n(6768)),o=n(8589);t.filterIconMap={quantitative:r.default,nominal:o.CheckSquare}},6768:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="rgba(0,0,0,0.4)",width:n=13,height:r=10}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",Object.assign({width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg"},a),o.default.createElement("path",{d:"M0.999998 3.33398L6.44444 3.33398",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}),o.default.createElement("path",{d:"M9.55566 3.33398L15.0001 3.33398",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}),o.default.createElement("path",{d:"M6.44444 1L6.44444 5.66667",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}))}},7288:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="rgba(0,0,0,0.4)",width:n=15,height:r=14}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",Object.assign({width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg"},a),o.default.createElement("path",{d:"M14.3333 1H1L6.33333 7.30667V11.6667L9 13V7.30667L14.3333 1Z",stroke:t,strokeLinecap:"round",strokeLinejoin:"round"}))}},2608:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="rgba(0,0,0,0.4)",width:n=13,height:r=10}=e,a=i(e,["color","width","height"]);return o.default.createElement("svg",Object.assign({width:n,height:r,viewBox:`0 0 ${n} ${r}`,fill:"none",xmlns:"http://www.w3.org/2000/svg"},a),o.default.createElement("path",{d:"M7.35254 1H9.99957V3.64703",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}),o.default.createElement("path",{d:"M1 9.99991L9.99991 1",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}),o.default.createElement("path",{d:"M9.99957 7.88086V10.5279H7.35254",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}),o.default.createElement("path",{d:"M6.82324 7.35352L9.99968 10.53",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}),o.default.createElement("path",{d:"M1 1.5293L3.64703 4.17633",stroke:t,strokeWidth:"1.25",strokeLinecap:"round",strokeLinejoin:"round",fill:t}))}},3578:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="rgba(0,0,0,0.4)"}=e;return i(e,["color"]),o.default.createElement("svg",{width:"16",height:"16",viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},o.default.createElement("rect",{x:"0.5",y:"0.5",width:"6",height:"6",rx:"0.5",stroke:t}),o.default.createElement("rect",{x:"9",width:"7",height:"7",rx:"1",fill:t}),o.default.createElement("rect",{x:"9.5",y:"9.5",width:"6",height:"6",rx:"0.5",stroke:t}),o.default.createElement("rect",{x:"0.5",y:"9.5",width:"6",height:"6",rx:"0.5",stroke:t}))}},5706:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271));t.default=function(e){var{color:t="rgba(0,0,0,0.4)"}=e;return i(e,["color"]),o.default.createElement("svg",{width:"12",height:"13",viewBox:"0 0 12 13",fill:"none",xmlns:"http://www.w3.org/2000/svg"},o.default.createElement("path",{d:"M1 4.75H11",stroke:t,strokeLinecap:"round",strokeLinejoin:"round"}),o.default.createElement("path",{d:"M1 8.5H11",stroke:t,strokeLinecap:"round",strokeLinejoin:"round"}),o.default.createElement("path",{d:"M4.75 1L3.5 12.25",stroke:t,strokeLinecap:"round",strokeLinejoin:"round"}),o.default.createElement("path",{d:"M8.5 1L7.25 12.25",stroke:t,strokeLinecap:"round",strokeLinejoin:"round"}))}},2372:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.typeIconMap=void 0;const r=i(n(5706)),o=i(n(3578));t.typeIconMap={quantitative:r.default,nominal:o.default}},200:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(6271),a=n(3242),s=i(n(5395)),l=i(n(5427)),c=i(n(6257)),d=n(6271),u=e=>r.css`
  // Global styles for the widget
  //===========================================================
  .bifrost-widget {
    height: 100%;
    max-height: fit-content;

    * {
      box-sizing: border-box;
    }

    button {
      cursor: pointer;
      transition: transform 0.4s;
      background-color: ${e.color.primary.dark};
      color: white;
      font-weight: 700;
      padding: 10px 15px;
      border-radius: 7px;
      font-size: 16px;
      border: none;

      &:active {
        transform: scale(0.95);
      }

      &:active:disabled {
        transform: scale(1);
      }
      &:disabled {
        opacity: 0.6;
        cursor: default;
      }

      &.wrapper {
        border: none;
        background: transparent;
        margin: 0;
        padding: 0;
        color: initial;
      }

      &.next-button {
        padding: 0;
        background-color: ${e.color.primary.dark};
        border: none;
        border-radius: 50%;
        cursor: pointer;
        height: 28px;
        width: 28px;
        margin-left: 20px;
      }
    }

    &.block {
      display: block;
    }

    h1 {
      font-size: 35px;
      font-weight: 800;
      margin: 10px 0;
      margin-bottom: 15px;
    }

    h2 {
      font-size: 25px;
      font-weight: 800;
    }

    .subtitle {
      font-size: 18px;
      color: gray;
      font-weight: 700;
      margin: 0;
    }

    input[type='checkbox'] {
      all: unset;
      width: 13px;
      height: 13px;
      display: inline-block;
      cursor: pointer;
      border: 1px solid #aaa;
      border-radius: 20%;
      margin-right: 6px;
      position: relative;
    }

    input[type='checkbox']:disabled {
      cursor: default;
    }

    input[type='checkbox']:checked {
      background: #771c79;
    }

    input[type='checkbox']:checked::after {
      position: absolute;
      color: white;
      content: '✓';
      padding-left: 1px;
      line-height: 1;
    }

    input[type='checkbox']:focus-visible {
      outline: auto;
    }
  }
`;function p(){const e=a.useModelState("passed_encodings")[0],t=a.useModelState("passed_kind")[0],[n,i]=o.useState(Boolean(e.x&&e.y&&t));return d.useEffect((()=>{const e=document.getElementsByClassName("jupyter-widgets");Array.from(e).forEach((e=>{e.children[0].classList.contains("bifrost-widget")&&(e.style.overflow="hidden")}))}),[]),r.jsx("div",{className:"bifrost-widget-display"},n?r.jsx(c.default,{onPrevious:()=>i(!1)}):r.jsx(l.default,{onOnboarded:()=>i(!0),plotArgs:e}))}t.default=function(e){return r.jsx(r.ThemeProvider,{theme:s.default},r.jsx(a.BifrostModelContext.Provider,{value:e.model},r.jsx(r.Global,{styles:u}),r.jsx(p,null)))}},2079:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(3242),a=n(5076),s=n(6271),l=i(n(2763)),c=i(n(5395)),d=i(n(7604)),u=i(n(7533)),p=r.css`
  padding-left: 34px;
  overflow-x: auto;

  g.mark-text.role-axis-title {
    text.hovered {
      fill: ${c.default.color.primary.dark};
    }
  }
`,f=r.css`
  cursor: pointer;
`;function g({graphSpec:e,setGraphSpec:t,field:n,axis:i}){const[l]=o.useModelState("df_column_ranges"),c=l[n],p=function(){var t;const i=e.transform.find((e=>{var t;return"or"in e.filter&&(null===(t=e.filter.or[0])||void 0===t?void 0:t.field)===n&&"range"in e.filter.or[0]}));return null===(t=null==i?void 0:i.filter.or)||void 0===t?void 0:t[0].range}(),f=u.default();function g(i){let r=i.slice();i[0]>i[1]&&(r=[i[1],i[0]]);const o=a.updateSpecFilter(e,n,"range",r);t(o)}s.useEffect((()=>{p||g(c)}),[]);const h="y"===i?{position:"absolute",bottom:"-20px",left:"-450px",transformOrigin:"right center",transform:"rotate(90deg)"}:void 0,m="y"===i?470:640;return r.jsx("div",{style:h},r.jsx(d.default,{width:m,domain:c,values:p,onUpdate:e=>g(e),onSlideEnd:()=>f(e,`Updated the filter range for ${n}`),vertical:"y"===i,reversed:"y"===i,onAxis:!0}))}t.default=function(e){const[t,n]=o.useModelState("selected_data"),[i,c]=o.useModelState("graph_spec"),[d,u]=o.useModelState("graph_bounds"),[h,m]=s.useState({activeAxis:e.clickedAxis}),x=o.useModelState("graph_data")[0];s.useEffect((()=>{["x","y"].includes(e.clickedAxis)?m({activeAxis:e.clickedAxis}):m({activeAxis:""})}),[e.clickedAxis]);const b={data:x},v={brush:function(...e){n(e)}};function y(e){const t=e.getBoundingClientRect();return{top:t.top,right:t.right,bottom:t.bottom,left:t.left}}function j(t){var n;if(!e.sideBarOpen)return void e.clickSidebarButton();const r=i.encoding[t].field,o=null===(n=e.sideBarRef.current)||void 0===n?void 0:n.getElementsByClassName("pill-list")[0];let a=h.activeAxis===t?"":t;if(o){const e=o.getElementsByClassName("graph-pill");e&&Array.from(e).forEach((e=>{e.querySelectorAll(".pill-header span")[1].textContent===r&&e.querySelectorAll(".pill-header span")[1].click()}))}else a="";e.updateClickedAxis(a)}function w(t){if(!e.graphRef)return;const n=e.graphRef.current;if("x"===t){const e=null==n?void 0:n.querySelector("g[aria-label^='X-axis'] .mark-text.role-axis-title text");null==e||e.classList.add("hovered")}else{const e=null==n?void 0:n.querySelector("g[aria-label^='Y-axis'] .mark-text.role-axis-title text");null==e||e.classList.add("hovered")}}function _(t){if(!e.graphRef)return;const n=e.graphRef.current;if("x"===t){const e=null==n?void 0:n.querySelector("g[aria-label^='X-axis'] .mark-text.role-axis-title text");null==e||e.classList.remove("hovered")}else{const e=null==n?void 0:n.querySelector("g[aria-label^='Y-axis'] .mark-text.role-axis-title text");null==e||e.classList.remove("hovered")}}return r.jsx("div",{css:p,onDoubleClick:function(){const e=Object.keys(d).reduce(((e,t)=>{const n=Object.values(i.encoding).find((e=>e.field===t)),r=n.type;if(!n)return e;const o=a.deleteSpecFilter(e,t,"quantitative"===r?"range":"oneOf",{compoundOperator:"and"});return a.addDefaultFilter(o,x,r,t)}),i);c(e),u({})}},r.jsx("div",{onMouseUp:function(){if(!t[1]||!Object.keys(t[1]).length)return;const e=t[1],n=Object.keys(e).reduce(((t,n)=>{const r=Object.values(i.encoding).find((e=>e.field===n)),o=r.type;return r?a.updateSpecFilter(t,n,"quantitative"===o?"range":"oneOf",e[n],{compoundOperator:"and"}):t}),i);c(n),u(e)},onMouseLeave:()=>n(["brush",{}])},r.jsx(l.default,{spec:i,data:b,signalListeners:"brush"===e.selection?v:void 0,renderer:"svg",actions:!1,onNewView:function(t){setTimeout((()=>function(){if(!e.graphRef.current)return;const t=e.graphRef.current,n=t.getBoundingClientRect(),i=function(e){const t=e.querySelector("g[aria-label^='X-axis'] .mark-text.role-axis-title"),n=e.querySelector("g[aria-label^='Y-axis'] .mark-text.role-axis-title"),i={};return t&&(i.x=y(t)),n&&(i.y=y(n)),i}(t),r=i.x,o=i.y,a=t.getElementsByClassName("x-axis-wrapper")[0],s=t.getElementsByClassName("y-axis-wrapper")[0];r&&a.setAttribute("style",`width:${r.right-r.left}px; height: ${r.bottom-r.top}px;\n        position: absolute;\n        left: ${r.left-n.left}px;\n        top: ${r.top-n.top+40}px;\n        `),o&&s.setAttribute("style",`width:${o.right-o.left}px; height: ${o.bottom-o.top}px;\n        position: absolute;\n        left: ${o.left-n.left}px;\n        top: ${o.top-n.top+40}px;`)}()),100),e.onViewCreated(t)}})),r.jsx("div",{className:"x-axis-wrapper",onClick:()=>j("x"),onMouseEnter:()=>w("x"),onMouseLeave:()=>_("x"),css:f}),r.jsx("div",{className:"y-axis-wrapper",onClick:()=>j("y"),onMouseEnter:()=>w("y"),onMouseLeave:()=>_("y"),css:f}),""!==h.activeAxis&&h.activeAxis in i.encoding&&!["nominal","oridnal"].includes(i.encoding[h.activeAxis].type)&&r.jsx(g,{graphSpec:i,setGraphSpec:c,field:i.encoding[h.activeAxis].field,axis:h.activeAxis}))}},3559:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(6271),a=n(8589),s=i(n(5238)),l=i(n(4296)),c=n(9767),d={bifrostRecommendedCharts:()=>r.jsx(s.default,{children:c.chartRecs}),editChart:()=>r.jsx(s.default,{children:c.editChart}),exportChart:()=>r.jsx(s.default,{children:c.exportChart}),addVariable:()=>r.jsx(s.default,{children:c.addVariable}),changeEncoding:()=>r.jsx(s.default,{children:c.changeEncoding}),applyOptions:()=>r.jsx(s.default,{children:c.applyOptions}),changeMarkType:()=>r.jsx(s.default,{children:c.changeMarkType}),accessHistory:()=>r.jsx(s.default,{children:c.accessHistory})},u=[{title:"Bifrost Recommended Charts",screen:"bifrostRecommendedCharts"},{title:"Edit a Chart",screen:"editChart"},{title:"Export Chart",screen:"exportChart"},{title:"Add a Variable",screen:"addVariable"},{title:"Change an Encoding",screen:"changeEncoding"},{title:"Apply Variable Options",screen:"applyOptions"},{title:"Change Mark Type",screen:"changeMarkType"},{title:"Access History",screen:"accessHistory"}],p=e=>r.css`
  nav {
    ul {
      display: flex;
      justify-content: flex-start;
      align-items: center;
      list-style: none;
      margin: 0;
      padding: 0;
    }
    li {
      margin: 0;
    }
  }

  .help-content {
    h2 {
      margin-bottom: 10px;
    }
    ul {
      margin: 5px;
      padding-left: 0;
    }
    li {
      line-height: 20px;
      margin: 10px 0;
    }

    pre {
      background-color: whitesmoke;
      padding: 10px;
      border-radius: 5px;
    }
    blockquote {
      background: ${e.color.primary.light};
      border-left: 3px solid ${e.color.primary.standard};
      margin: 0;
      padding: 10px 20px;
    }
  }
`;t.default=function({position:e=[0,0],onDismiss:t}){const[n,i]=o.useState("");return r.jsx(l.default,{position:e,onBack:t,style:{width:330,maxHeight:400,overflow:"auto"}},n?r.jsx("section",{className:"HelpScreen",css:p},r.jsx("nav",{className:"graph-nav-bar"},r.jsx("ul",null,r.jsx("li",null,r.jsx("button",{className:"wrapper",onClick:()=>i("")},r.jsx(a.ArrowLeft,null))))),r.jsx("div",{className:"help-content"},d[n]())):r.jsx(g,{onLinkClick:i}))};const f=r.css`
  h2 {
    margin-bottom: 10px;
  }
  ul {
    list-style: none;
    padding: 0;
    margin: 0;
    line-height: 25px;
    a:hover {
      text-decoration: underline;
    }
  }
`;function g(e){return r.jsx("section",{className:"HelpLinks",css:f},r.jsx("h2",null,"Help"),r.jsx("ul",null,u.map((({title:t,screen:n})=>r.jsx("li",{key:t},r.jsx("a",{onClick:t=>{t.preventDefault(),e.onLinkClick(n)}},t)))),r.jsx("li",null,r.jsx("a",{href:"https://github.com/jupytercalpoly/Jupyter-Bifrost",target:"_blank"},"GitHub Repository"))))}},9767:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.accessHistory=t.changeMarkType=t.applyOptions=t.changeEncoding=t.addVariable=t.exportChart=t.editChart=t.chartRecs=void 0,t.chartRecs="\n## Bifrost Recommended Charts\n- Launch Bifrost with an empty bifrost.plot() function.\n```\nresult = df.bifrost.plot()\n```\n- Select up to three initial columns to analyze.\n- Scroll to and click on a recommended chart to begin editing or to export.\n- To filter these recommended charts by mark type, use the mark type icons.\n",t.editChart="\n## Edit a Chart\n- Select a recommended chart or define one using `bifrost.plot`.\n- Click the three dot menu icon in the top right corner of your chart. From here, you can edit your data, mark type, or access your history of edits.\n",t.exportChart="\n## Export Chart\n- Click the 'more' icon in the top left corner of your chart.\n- Select export option.\n> Note: Exporting your dataframe will copy it to your clipboard.\n",t.addVariable="\n## Add a Variable\n- Open the side menu.\n- Click the plus icon.\n- Select a variable. \n    - Click one of the pills to set the variable\n- Select a datafield to encode.\n    - To go back to change the encoding, simply click the encoding.\n- Click X button to cancel. \n",t.changeEncoding="\n## Change an Encoding\n- Open the side menu.\n- Click on the variable type, variable, or datafield you would like to change within the data pill.\n- Select an option from the list below.\n",t.applyOptions="\n## Apply Variable Options\n> Note: You can apply filters to any data pill. For quantitative variables you can also apply aggregations, scaling, and binning. \n\n- Open the side menu. \n- Click the options button on the desired data pill. \n- For a categorical filter, select or deselect desired fields.\n- For a quantitative variable, use the slider to apply a range filter. Press the add filter button to add multiple. Use the dropdown menus to apply aggregation, binning and scaling.\n",t.changeMarkType="\n## Change Mark Type\n- Navigate to the data tab in the side menu.\n- Click a mark icon () to change mark. Hover to see kinds of marks.\n",t.accessHistory="\n## Access History\n- Click on the history tab.\n- Select any edit entry from the list. They are listed in chronological order. \n- If you jump back to any previous state and make new edits, Bifrost will maintain both your original and new edits. The new ones will be kept as a parent of the state you are editing. \n"},132:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(8589),a=n(6271),s=i(n(3559)),l=i(n(1399)),c=r.css`
  .menu-list {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    list-style: none;
    margin: 0;
    padding: 0;
  }
  .menu-option {
    margin: 0 10px;
  }
`;t.default=function(e){const[t,n]=a.useState(!1),[i,d]=a.useState(!1);return r.jsx("nav",{className:"graph-nav-bar",css:c},r.jsx("ul",{className:"menu-list"},r.jsx("li",{className:"menu-option"},r.jsx("button",{className:"wrapper",onClick:e.onBack},r.jsx(o.ArrowLeft,null))),r.jsx("li",{className:"menu-option"},r.jsx("button",{className:"wrapper",onClick:()=>n(!0)},r.jsx(o.HelpCircle,null))),r.jsx("li",{className:"menu-option"},r.jsx("button",{className:"wrapper",onClick:()=>d(!0)},r.jsx(o.MoreHorizontal,null))),r.jsx("li",{className:"selection"},r.jsx("button",{className:"wrapper",onClick:e.toggleSelection},e.selection))),t&&r.jsx(s.default,{onDismiss:()=>n(!1)}),i&&r.jsx(l.default,{view:e.vegaView,onBack:()=>d(!1)}))}},7780:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=i(n(7179)),a=n(6271),s=n(6271),l=n(7266),c=n(3242),d=i(n(1090)),u=e=>r.css`
  width: 100%;
  max-height: 400px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  position: relative;
  overflow: hidden;
  .title {
    margin: 0;
  }

  .center-col {
    display: grid;
    height: 100%;
    button,
    ul {
      align-self: flex-start;
    }
  }

  .chart-col {
    position: relative;
    max-height: 100%;
    width: 100%;
    align-self: flex-start;
    overflow: hidden;
  }

  .suggested-charts {
    height: 315px;
    margin-left: 10px;
    scroll-behavior: smooth;
    scroll-snap-type: x mandatory;
    scroll-snap-align: center;
    overflow-x: scroll;
    overflow-y: hidden;
    display: flex;
    align-items: center;
    flex-wrap: nowrap;

    @media screen and (max-width: 1200px) {
      max-height: 500px;
    }
  }

  .graph-wrapper {
    position: relative;
    margin: 40px 0;
    padding: 0;
    background-color: transparent;
    border: none;
    border-radius: 5px;
    transition: border-color 0.5s;
    border: 10px solid transparent;
    transition: border-color 0.4s;
    flex: 0 0 auto;

    &:active {
      transform: scale(1);
    }

    &.focused,
    &:hover {
      border: 10px solid ${e.color.primary.light};
    }
  }
`;t.default=function(e){const[t,n]=s.useState(""),i=c.useModelState("suggested_graphs")[0],p=c.useModelState("selected_columns")[0],f=a.useMemo((()=>t?i.filter((e=>t===e.mark)):i),[t,i]),g=a.useMemo((()=>i.reduce(((e,{mark:t})=>(e.add(t),e)),new Set)),[i]),h=c.useModelState("graph_data")[0],m=c.useModelState("graph_spec")[1],x=c.useModelState("spec_history")[1],b={data:h};function v(t){if(-1===t)return;const n=o.default(i[t],(e=>{e.height=420,e.width=550,e.config={mark:{tooltip:!0}},e.params=[{name:"grid",select:"interval",bind:"scales"}];const t=Object.values(e.encoding).map((e=>e.field)).join(" vs. ");e.description=`Chose the ${t} ${e.mark} plot`}));m(n),x([n]),e.onOnboarded()}return i.length&&p.length?r.jsx("section",{tabIndex:-1,className:"ChartChooser",css:u},r.jsx(d.default,{filteredMark:t,availableMarks:g,onChange:n}),r.jsx("div",{className:"chart-col"},!!f.length&&r.jsx("div",{style:{paddingBottom:10}},r.jsx("h2",{className:"title"},"Recommended Charts"),r.jsx("h3",{className:"subtitle"},"Select a chart to explore the dataset")),r.jsx("div",{className:"suggested-charts"},f.map(((e,t)=>r.jsx("button",{onClick:()=>v(t),onKeyDown:e=>function(e,t){" "===e.key&&(e.preventDefault(),e.stopPropagation(),v(t))}(e,t),style:{scrollSnapAlign:"center"},className:"graph-wrapper",key:t,"data-focusable":"chart"+t},r.jsx(l.VegaLite,{spec:e,data:b,actions:!1}))))))):r.jsx("div",null)}},1090:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=i(n(5395)),a=n(9873),s=i(n(5180)),l=e=>r.css`
  margin: 5px;

  h3 {
    margin: 0;
    text-align: center;
  }

  ul {
    list-style: none;
    padding: 15px;
    border-radius: 15px;
    background-color: white;
    border: 1px solid #e0e0e0;
    margin: 7px 0;
    li {
      padding: 0;
      margin: 10px 0;
    }
  }
`;t.default=function({onChange:e,filteredMark:t,availableMarks:n}){return r.jsx("div",{className:"ChartFilter",css:l},r.jsx("h3",null,"Filter"),r.jsx("ul",null,a.chartIcons.filter((({mark:e})=>n.has(e))).map((({mark:n,icon:i})=>r.jsx("li",{key:n},r.jsx(s.default,{message:n,position:"right"},r.jsx("button",{className:"wrapper",onClick:()=>function(n){e(n===t?"":n)}(n)},r.jsx(i,{color:n===t?o.default.color.primary.dark:"#bbbbbb"}))))))))}},603:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(6271),a=i(n(4618)),s=n(8589),l=n(6271),c=n(3242),d=i(n(2890)),u=n(6271),p=n(4934),f=i(n(3863)),g=i(n(7179)),h=i(n(3559)),m=e=>r.css`
  flex: 0 0 320px;
  margin-right: 30px;
  padding-right: 30px;
  border-right: 1px solid #cecece;
  h2,
  h3 {
    margin: 0;
  }
  .title-wrapper {
    position: relative;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .choice {
    display: flex;
    margin: 5px 0;
    padding: 5px;
    width: fit-content;
    border-left: 2px solid transparent;

    &.focused {
      border-left: 2px solid ${e.color.primary.standard};
    }
  }

  form {
    margin-top: 12px;
    border-bottom: 1px solid #cecece;
  }

  fieldset {
    max-height: 270px;
    overflow: auto;
    border: none;
  }

  .column-tags {
    padding: 0px;
    display: flex;
    flex-wrap: wrap;
  }

  .tag-content-wrapper {
    display: flex;
    justify-content: space-between;
    white-space: nowrap;
    overflow: hidden;
    align-items: center;
  }

  .tag-content-wrapper button {
    border: none;
    width: 20px;
    height: 20px;
    background-color: #dedede;
    color: var(--jp-widgets-color);
    border-radius: 50%;
    cursor: pointer;
    padding: 0px;
    margin: 0;
  }

  .tag-content-wrapper button:hover {
    background-color: #eee;
  }
`;t.default=function(e){const[t,n]=o.useState(""),[i,x]=o.useState(!1),b=c.useModelState("df_columns")[0],[v,y]=c.useModelState("selected_columns"),j=c.useModelState("column_types")[0],w=c.useModelState("query_spec")[0],_=c.useModelState("graph_data")[0],k=c.useModelState("suggested_graphs")[1],[O,M]=o.useState(b.map(((e,t)=>({choice:e,index:t})))),S=o.useRef(null),E=u.useMemo((()=>new Set(Object.values(e.plotArgs).filter(Boolean))),[e.plotArgs]);function C(e){const t=new Set(v);e.target.checked&&v.length>2?e.target.checked=!1:(e.target.checked?t.add(e.target.value):t.delete(e.target.value),y(Array.from(t)))}return l.useEffect((function(){const e=p.data2schema(_),t=p.schema2asp(e),n=v.map((e=>E.has(e)?w.spec.encodings.filter((t=>t.field===e))[0]:{field:e,type:j[e],channel:"?"})),i=p.cql2asp(Object.assign(Object.assign({},w.spec),{encodings:n})),r=new f.default;r.init().then((()=>{const e='data("data").\n'+t.concat(i).join("\n"),n=r.solve(e,{models:5}),o=e=>!("facet"in e.encoding||"row"in e.encoding);if(n){const e=n.specs.filter(o).map((e=>g.default(e,(e=>{delete e.$schema,delete e.data.url,e.data.name="data",e.transform=[],e.width=400,e.height=200,["circle","square"].includes(e.mark)&&(e.mark="point")}))));k(e)}}))}),[v]),r.jsx("aside",{className:"ColumnSelectorSidebar",css:m},r.jsx("div",{className:"title-wrapper"},r.jsx("h2",null,"Columns"),r.jsx("button",{className:"wrapper",onClick:()=>x(!0)},r.jsx(s.HelpCircle,null)),i&&r.jsx(h.default,{onDismiss:()=>x(!1),position:["100%",0]})),r.jsx("h3",{className:"subtitle"},"Select up to 3 columns"),r.jsx(a.default,{"data-immediate-focus":!0,"data-focusable":"search",choices:b,value:t,onChange:n,onResultsChange:M}),r.jsx("form",{onSubmit:e=>e.preventDefault()},r.jsx("fieldset",{ref:S},O.map((({choice:e},t)=>r.jsx("label",{className:"choice","data-focusable":!0,key:e},E.has(e)?r.jsx(s.Lock,{size:15,style:{marginRight:"6px"}}):r.jsx("input",{className:`choice_${e}`,type:"checkbox",value:e,onChange:C,checked:v.includes(e)}),e))))),r.jsx("ul",{className:"column-tags"},v.map(((e,t)=>r.jsx(d.default,{key:e,style:{margin:4,padding:4}},r.jsx("div",{className:"tag-content-wrapper"},r.jsx("span",{style:{padding:"0px 5px",fontSize:12}},e),r.jsx("button",{className:`tagButton_${e}`,onClick:()=>function(e){const t=new Set(v);t.delete(e),y(Array.from(t))}(e)},r.jsx(s.X,{size:10}))))))))}},2247:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.useKeyboardNavigation=void 0;const i=n(6271),r="[data-focusable]";t.useKeyboardNavigation=function({jumpTo:e={},keyEvents:t={}}={}){const n=i.useRef(null),o=i.useState(0)[1];return i.useEffect((()=>{var e;const t=null===(e=n.current)||void 0===e?void 0:e.querySelector("[data-immediate-focus]");null==t||t.focus()}),[]),i.useEffect((()=>{var i;function a(e){o((t=>{if(!n.current)return t;const i=n.current.querySelectorAll(r);if(!i.length)return t;i.forEach((e=>{e.classList.remove("focused"),e.blur()}));const o=Math.max(Math.min(i.length-1,t+e),0);return i[o].focus(),i[o].scrollIntoView({behavior:"smooth",block:"center"}),i[o].classList.add("focused"),o}))}function s(i){switch(i.key){case"ArrowUp":i.preventDefault(),i.stopPropagation(),a(-1);break;case"ArrowDown":i.preventDefault(),i.stopPropagation(),a(1)}i.key in e&&function(e){if(!n.current)return;const t=Array.from(n.current.querySelectorAll(r));if(!t.length)return;t.forEach((e=>{e.classList.remove("focused"),e.blur()}));const i=t.findIndex((t=>t.dataset.focusable===e));i<0||(t[i].focus(),t[i].scrollIntoView({behavior:"smooth",block:"center"}),t[i].classList.add("focused"),o(i))}(e[i.key]),i.key in t&&t[i.key](i)}return null===(i=n.current)||void 0===i||i.addEventListener("keydown",s),()=>{var e;null===(e=n.current)||void 0===e||e.removeEventListener("keydown",s)}}),[n.current]),n}},5427:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=i(n(7780)),a=i(n(603)),s=n(3242),l=n(2247),c=n(6271),d=i(n(7179)),u=r.css`
  position: relative;
  display: flex;
  padding: 20px;
  width: 100%;
  @media screen and (max-width: 1200px) {
    flex-direction: column;

    .ChartChooser {
      margin-top: 30px;
    }
  }
`;t.default=function(e){const t=l.useKeyboardNavigation({jumpTo:{ArrowLeft:"search",ArrowRight:"chart0"}}),[n,i]=s.useModelState("graph_data_config");return c.useEffect((()=>{const e=100!==n.sampleSize,t=Math.min(5e3,n.datasetLength);return e&&i(d.default(n,(e=>{e.sampleSize=100}))),()=>{setTimeout((()=>{i(d.default(n,(n=>{n.sampleSize=e?n.sampleSize:t})))}),100)}}),[]),r.jsx("article",{className:"OnboardingWidget",css:u,ref:t},r.jsx(a.default,{plotArgs:e.plotArgs}),r.jsx(o.default,{onOnboarded:e.onOnboarded}))}},1141:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(6271),a=i(n(5639)),s=i(n(4402)),l=i(n(5911)),c=n(9567),d=i(n(5395)),u=r.css`
  .side-bar-transition-enter {
    opacity: 0.01;
    &.side-bar-transition-enter-active {
      opacity: 1;
      transition: opacity 500ms ease-in;
    }
  }

  .side-bar-transition-leave {
    opacity: 1;
    &.side-bar-transition-leave-active {
      opacity: 0.01;
      transition: opacity 300ms ease-in;
    }
  }
  .side-bar-transition-appear {
    opacity: 0.01;
    &.side-bar-transition-appear-active {
      opacity: 1;
      transition: opacity 0.5s ease-in;
    }
  }
`,p=r.css`
  position: relative;
  display: grid;
  grid-template-rows: auto 1fr;
  width: 100%;
  max-width: 330px;
  min-height: 400px;
  border-radius: 10px;
  box-shadow: ${d.default.shadow.handle};
  margin: 8px;

  .sidebar-content {
    position: relative;
    border-top: 2px solid #e4e4e4;
    padding: 10px;
    padding-bottom: 0;
    height: 100%;
    display: flex;
    justify-content: column;
    overflow: hidden;
  }
`,f={Edit:a.default,History:s.default,Nearby:l.default};t.default=function(e){const t=["Edit","History","Nearby"],[n,i]=o.useState(t[0]),a=f[n];return r.jsx(c.CSSTransitionGroup,{transitionName:"side-bar-transition",transitionAppear:!0,transitionAppearTimeout:500,transitionEnterTimeout:500,transitionLeaveTimeout:300,css:u},r.jsx("aside",{css:p},r.jsx(h,{tabs:t,onTabSelected:i,activeTab:n}),r.jsx("div",{className:"sidebar-content"},r.jsx(a,{clickedAxis:e.clickedAxis,updateClickedAxis:e.updateClickedAxis}))))};const g=e=>r.css`
  ul {
    display: flex;
    justify-content: space-around;
    align-items: center;
    list-style: none;
    padding: 0;
    margin: 0;
    padding: 8px 30px;
  }
  li {
    background: transparent;
    cursor: pointer;
    border-bottom: none;
    transform: scale(1);
    transition: transform 0.5s;
    padding: 5px 20px;
    border-radius: 7px;

    &:active {
      transform: scale(0.95);
    }

    &.selected {
      font-weight: 800;
      background-color: ${e.color.primary.dark};
      color: white;
    }
  }
`;function h(e){return r.jsx("nav",{className:"TabBar",css:g},r.jsx("ul",null,e.tabs.map((t=>r.jsx("li",{className:e.activeTab===t?"selected":"",onClick:()=>e.onTabSelected(t),key:t},t)))))}},4998:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(6271),a=n(8589),s=n(3242),l=n(2696),c=i(n(2890)),d=i(n(4618)),u=i(n(7179)),p=i(n(7533)),f=n(5076),g=n(6121),h=n(6271),m=e=>r.css`
  button {
    background: transparent;
    color: initial;
  }

  .cancel-button {
    float: right;
  }

  .datafield-button {
    border-radius: 0 7px 7px 0;
  }

  .variable-button {
    border-radius: 7px 0 0 7px;
  }

  .datafield-button,
  .variable-button {
    background-color: ${e.color.primary.light};
    color: ${e.color.primary.dark};
    flex: 1 1 50%;
    font-weight: normal;
    padding: 6px;

    &.selected {
      background-color: ${e.color.primary.dark};
      color: white;
      font-weight: bold;
    }
  }
`;function x({updateSelectedEncoding:e,onEncodingSelected:t}){const[n]=s.useModelState("graph_spec");return r.jsx("ul",{className:"encoding-choices"},l.vegaMarkEncodingMap[n.mark].filter((e=>!(e in n.encoding))).map((n=>r.jsx(c.default,{key:n,onClick:()=>function(n){e(n),t("datafield")}(n)},r.jsx("span",{style:{padding:"3px 10px"}},n)))))}function b({updateSelectedDataField:e}){const[t]=s.useModelState("df_columns"),[n,i]=o.useState(""),[a,l]=o.useState(t.map(((e,t)=>({choice:e,index:t}))));return r.jsx("div",null,r.jsx(d.default,{choices:t,onChange:i,value:n,onResultsChange:l,placeholder:"Search Columns"}),r.jsx("ul",{className:"columns-list"},a.map((({choice:t})=>r.jsx("li",{className:"column-el",key:t,onClick:()=>e(t)},t)))))}t.default=function(e){const[t,n]=o.useState(""),[i,l]=o.useState(""),[c]=s.useModelState("column_types"),[d,v]=s.useModelState("graph_spec"),[y]=s.useModelState("graph_data"),j=p.default(),[w,_]=o.useState("var");function k(e){w!==e&&_(e)}return h.useEffect((()=>{""!==t&&""!==i&&function(){const n=c[i];let r=u.default(d,(e=>{""!==t&&(e.encoding[t]={field:i,type:n})}));r=g.hasDuplicateField(r,i)?r:f.addDefaultFilter(r,y,n,i);const o=u.default(e.pillsInfo,(e=>{e.push({field:i,encoding:t,aggregation:"",type:n,scale:"",filters:[]})}));e.updatePillState(o),j(r,`Applied the ${i} field to ${t}`),v(r),e.onPrevious()}()}),[t,i]),r.jsx("article",{className:"add-new-pill-screen",css:m},r.jsx("nav",null,r.jsx("button",{className:"cancel-button",onClick:e.onPrevious},r.jsx(a.X,null))),r.jsx("nav",{style:{display:"flex",width:"100%"}},r.jsx("button",{className:"var"===w?"variable-button selected":"variable-button",onClick:()=>k("var")},""===t?"var":`encoding: ${t}`),r.jsx("button",{className:"datafield"===w?"datafield-button selected":"datafield-button",onClick:()=>k("datafield")},""===i?"datafield":`datafield: ${i}`)),"var"===w?r.jsx(x,{updateSelectedEncoding:function(e){e!==t&&n(e)},onEncodingSelected:k}):r.jsx(b,{updateSelectedDataField:function(e){e!==i&&l(e)}}))}},5639:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=i(n(7179)),a=n(6271),s=n(8589),l=n(3242),c=n(2696),d=i(n(7533)),u=i(n(2890)),p=i(n(4618)),f=i(n(1542)),g=n(5076),h=n(6121),m=i(n(1439)),x=n(6271),b=n(9873),v=i(n(4998)),y=i(n(551)),j=i(n(5180)),w=e=>r.css`
  position: relative;
  width: 100%;
  overflow: scroll;

  h3 {
    .data-section,
    .sampling-section {
      cursor: pointer;
      transition: transform 0.2s ease-in-out;
      &.open,
      &.open {
        transform: rotate(180deg);
      }
    }
  }

  .mark-list {
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0;

    button {
      padding: 5px;
      padding-top: 7px;
      border-radius: 5px;
      background: transparent;

      &:disabled {
        opacity: 0.4;
      }

      &.active {
        background: ${e.color.primary.dark};
      }
    }
  }

  .pill-list,
  .encoding-choices {
    margin: 0;
    padding: 0;

    .encoding-wrapper {
      display: flex;
      b {
        margin-right: 5px;
      }
    }
  }

  .pill-list {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
  }

  .add-pill {
    margin: 10px;
    width: min-content;
    height: min-content;
    padding: 2px;
    padding-bottom: 0px;
  }

  .encoding-choices {
    max-height: 150px;
    overflow: auto;
  }
  .columns-list {
    list-style: none;
    padding: 0;
    height: 300px;
    overflow: auto;

    .column-el {
      padding: 10px;
      transition: background-color 0.5s;
      background-color: white;
      &:hover {
        background-color: whitesmoke;
      }
    }
  }

  .dataset-percentage {
    margin-left: 13px;
    margin-bottom: 5px;
  }
`;function _(e,t,n,i){const r=g.getFilterList(e);let o=Object.assign({},e);return r.length||Object.values(o.encoding).filter((e=>e.field)).map((e=>{const r=e.field;if(["ordinal","nominal"].includes(n[r]))o=g.updateSpecFilter(o,r,"oneOf",g.getCategories(t,r));else{const e=i[r];isFinite(e[0])&&(o=g.updateSpecFilter(o,r,"range",e))}})),o}function k(e,t){var n,i;const r=null===(n=t.encoding.x)||void 0===n?void 0:n.type,o=null===(i=t.encoding.y)||void 0===i?void 0:i.type,a=e=>e.length>1?e[0]===r&&e[1]===o||e[1]===r&&e[0]===o:1===e.length&&(r===e[0]||o===e[0]),s=[[void 0,"quantitative"],["nominal","quantitative"],["quantitative","quantitative"]];switch(e){case"bar":return![[void 0,void 0],["quantitative",void 0]].some((e=>a(e)));case"point":return![[void 0,void 0],["nominal",void 0]].some((e=>a(e)));case"line":return a(["quantitative","quantitative"]);case"tick":case"boxplot":case"errorband":case"errorbar":return s.some(a);default:return!0}}t.default=function({clickedAxis:e,updateClickedAxis:t}){const n=l.useModelState("df_columns")[0],[i,O]=l.useModelState("column_types"),[M]=l.useModelState("df_column_ranges"),S=l.useModelState("graph_data")[0],[E,C]=a.useState(""),[$,N]=a.useState(n.map(((e,t)=>({choice:e,index:t})))),[P,L]=a.useState(""),[D,A]=l.useModelState("graph_spec"),[F,B]=l.useModelState("graph_data_config"),[V]=l.useModelState("graph_data"),[R,z]=a.useState({menu:"",encoding:""}),I=x.useRef(!0),[T,q]=a.useState(!0),[H,U]=a.useState(!0),[W,G]=a.useState(!1),[K,X]=a.useState([]);a.useEffect((()=>{z((t=>Object.assign(Object.assign({},t),{encoding:e})))}),[e]);const Y=d.default();a.useEffect((()=>{const e=_(D,V,i,M);A(e),X(function(e){const t=Object.entries(e.encoding).reduce(((e,[t,n])=>{var i;const r=n.field,o={field:r,encoding:t,aggregation:n.aggregate||"",type:n.type,filters:[],scale:(null===(i=n.scale)||void 0===i?void 0:i.type)||""};return e[r]?e[r].push(o):e[r]=[o],e}),{});return g.getFilterList(e).forEach((e=>{e.field in t?t[e.field].forEach((t=>t.filters.push(...g.stringifyFilter(e)))):t[e.field]=[{field:e.field,encoding:"",aggregation:"",type:"filter",filters:g.stringifyFilter(e),scale:""}]})),Object.values(t).flat()}(e)),"object"==typeof e.mark?L(e.mark.type):"string"==typeof e.mark&&L(e.mark)}),[]),a.useEffect((function(){if(I.current)I.current=!1;else{if(!function(e){return Object.keys(e.encoding).length===e.transform.length}(D)){const e=_(D,V,i,M);A(e)}X((e=>o.default(e,(e=>{e.forEach((e=>{var t,n,i;e.filters=[],e.aggregation=(null===(t=D.encoding[e.encoding])||void 0===t?void 0:t.aggregate)||"";const r=null===(i=null===(n=D.encoding[e.encoding])||void 0===n?void 0:n.scale)||void 0===i?void 0:i.type;e.scale="linear"!==r&&r?r:""})),g.getFilterList(D).forEach((t=>{e.forEach((e=>{e.field===t.field&&e.filters.push(...g.stringifyFilter(t))}))}))}))))}}),[D]);const Z=K.map(((e,n)=>r.jsx(m.default,Object.assign({onClose:()=>function(e){const n=e.encoding,r="filter"===e.type;let a=h.hasDuplicateField(D,e.field)?D:g.deleteSpecFilter(D,e.field,"quantitative"===i[e.field]?"range":"oneOf",{deleteCompound:!0});r||(a=o.default(a,(e=>{delete e.encoding[n]})));const s=o.default(K,(t=>{const i=r?t=>""===t.encoding&&t.field===e.field:e=>e.encoding===n,o=t.findIndex(i);-1!==o&&t.splice(o,1)}));X(s),A(a),Y(a,`Removed the ${e.field} encoding from the ${a.mark} plot.`),n===R.encoding&&t(""),z({menu:"",encoding:""}),Y(a)}(e),onFilterSelected:()=>{return e.field&&(t=e.encoding,void z({menu:"filter",encoding:t}));var t},onFieldTypeSelected:()=>function(e,t){if("string"==typeof S[0][e])return;const n="nominal"===t?"quantitative":"nominal";O(Object.assign(Object.assign({},i),{[e]:n})),A(o.default(D,(t=>{const i=Object.values(t.encoding).find((t=>t.field===e));i&&(i.type=n)})));const r=o.default(K,(t=>{const i=t.find((t=>t.field===e));i&&(i.type=n)}));X(r)}(e.field,e.type),onEncodingSelected:()=>{const t=R.encoding!==e.encoding||"encoding"!==R.menu;z({menu:t?"encoding":"",encoding:t?e.encoding:""})},onFieldSelected:()=>{z((t=>{const n=t.encoding!==e.encoding||"field"!==R.menu;return{menu:n?"field":"",encoding:n?e.encoding:""}}))},selectedField:R.encoding===e.encoding?R.menu:"",position:n,key:n},e))));function J(e){"data"===e?q(!T):"sampling"===e&&U(!H)}return Z.push(r.jsx("button",{key:"add-pill",className:"add-pill",onClick:()=>{z({encoding:"",menu:""}),G(!0)}},r.jsx(s.Plus,{color:"white",size:25}))),r.jsx("section",{className:"DataTab",css:w},W?r.jsx(v.default,{pillsInfo:K,updatePillState:e=>X(e),onPrevious:()=>G(!1)}):"filter"===R.menu?r.jsx(f.default,{encoding:R.encoding,onBack:()=>z({encoding:"",menu:""})}):r.jsx("article",null,r.jsx("h3",null,"Data",r.jsx("div",{className:T?"data-section open":"data-section",style:{display:"inline-block"},onClick:()=>J("data")},r.jsx(s.ChevronUp,{size:12}))),T?r.jsx("section",null,r.jsx("ul",{className:"mark-list"},b.chartIcons.map((({icon:e,mark:t})=>r.jsx("li",{key:t},r.jsx(j.default,{message:t,position:"top"},r.jsx("button",{className:t===P?"active":"",onClick:()=>function(e){if(e===P)return;const t=o.default(D,(t=>{t.mark=e}));A(t),L(e),Y(t,`Updated mark to ${e}`)}(t),disabled:!k(t,D)},r.jsx(e,{color:t===P?"white":void 0}))))))),r.jsx("ul",{className:"pill-list"},Z),"encoding"===R.menu&&r.jsx("ul",{className:"encoding-choices"},c.vegaMarkEncodingMap[D.mark].filter((e=>!(e in D.encoding))).map((e=>r.jsx(u.default,{onClick:()=>function(e){if(D.encoding[e])return;const t=o.default(D,(t=>{R.encoding?(t.encoding[e]=t.encoding[R.encoding],delete t.encoding[R.encoding]):t.encoding[e]={field:"",type:""}}));z({menu:"",encoding:""});const n=o.default(K,(t=>{if(R.encoding){const n=K.findIndex((e=>e.encoding===R.encoding));if(-1===n)return;t[n].encoding=e}else t.push({field:"",encoding:e,aggregation:"",type:"",scale:"",filters:[]})}));X(n),A(t),z((e=>Object.assign(Object.assign({},e),{menu:""})))}(e)},r.jsx("span",{style:{padding:"3px 10px"}},e))))),"field"===R.menu&&r.jsx("div",null,r.jsx(p.default,{choices:n,onChange:C,value:E,onResultsChange:N,placeholder:"Search Columns"}),r.jsx("ul",{className:"columns-list"},$.map((({choice:n})=>r.jsx("li",{className:"column-el",key:n,onClick:()=>(n=>{if(!R.encoding)return;const r=i[n],a=D.encoding[R.encoding];if(a.field===n)return z((e=>Object.assign(Object.assign({},e),{menu:""})));let s=D;if(h.hasDuplicateField(s,n)||(s=g.deleteSpecFilter(s,a.field,"quantitative"===a.type?"range":"oneOf",{deleteCompound:!0})),s=o.default(s,(e=>{e.encoding[R.encoding]={field:n,type:r}})),!h.hasDuplicateField(s,n)){const e=i[n];s=g.addDefaultFilter(s,V,e,n)}const l=o.default(K,(e=>{const t=e.find((e=>e.encoding===R.encoding));t&&(t.field=n,t.type=r)}));A(s),e&&t(""),Y(s,`Assigned the '${n}' field to ${R.encoding}`),X(l),z((e=>Object.assign(Object.assign({},e),{menu:""})))})(n)},n)))))):r.jsx("section",null),r.jsx("section",null,r.jsx("h3",null,"Sampling",r.jsx("div",{className:H?"sampling-section open":"sampling-section",style:{display:"inline-block"},onClick:()=>J("sampling")},r.jsx(s.ChevronUp,{size:12}))),H?r.jsx("article",null,r.jsx("p",{className:"dataset-percentage"},Math.round(F.sampleSize/F.datasetLength*100),"% of dataset"),r.jsx(y.default,{value:F.sampleSize,domain:[1,F.datasetLength],onSlideEnd:function(e){B(Object.assign(Object.assign({},F),{sampleSize:Math.floor(e)}))},step:1})):r.jsx("div",null))))}},1542:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.filterMap=void 0;const r=n(7593),o=i(n(7179)),a=n(6271),s=n(8589),l=n(3242),c=n(2696),d=i(n(7604)),u=i(n(7533)),p=n(5076),f=e=>r.css`
  position: absolute;
  top: 0;
  background-color: ${e.color.background[0]};
  width: 100%;
  height: 100%;
  padding: 15px;

  .filter-nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
  }
  nav {
    padding-bottom: 5px;
  }

  h2 {
    font-weight: 700;
    margin: 0;
    .encoding {
      color: ${e.color.primary.dark};
    }
  }

  h3 {
    margin: 6px 0;
  }

  .close-slider {
    display: inline-block;
    margin-left: 5px;
  }

  .add-range {
    margin: 10px 0;
    margin-left: 10px;
    color: ${e.color.primary.dark};
  }

  .field-wrapper {
    display: inline-block;
    margin: 10px;
  }

  .field-label {
    display: block;
    font-size: 17px;
    font-weight: 500;
    margin-bottom: 2px;
  }

  .RangeSlider {
    padding-left: 0px;
  }

  .transformation-section {
    display: flex;
    align-items: center;

    article {
      margin-right: 10px;

      select {
        padding: 5px;
      }

      .bin-checkbox {
        margin: 5px 0;
      }
    }
  }

  .binning-button {
    background-color: ${e.color.primary.standard};
    color: white;
    padding: 5px;
    font-size: initial;

    &.clicked {
      background-color: ${e.color.primary.dark};
    }
  }

  .category-header {
    display: flex;
    align-items: center;
    justify-content: start;

    .toggle-all {
      margin-left: 10px;
      color: gray;
      font-size: 14px;
      cursor: pointer;

      &:hover {
        text-decoration: underline;
      }
    }
  }
`;t.filterMap={quantitative:function(e){var t;const[n,i]=l.useModelState("graph_spec"),[u]=l.useModelState("df_column_ranges"),{field:f}=n.encoding[e.encoding],g=n.encoding[e.encoding].aggregate,h=(null===(t=n.encoding[e.encoding].scale)||void 0===t?void 0:t.type)||"linear",m=u[f],x=function(){var e;const t="range";return(null===(e=n.transform.find((e=>{var n;return"or"in e.filter&&(null===(n=e.filter.or[0])||void 0===n?void 0:n.field)===f&&t in e.filter.or[0]})))||void 0===e?void 0:e.filter.or.map((e=>e.range)))||[]}();function b(e,t){const r=p.updateSpecFilter(n,f,"range",e,{occurrence:t+1});i(r)}return a.useEffect((()=>{x.length||b(m,0)}),[]),r.jsx("section",{className:"quantitative-filters"},r.jsx("article",{className:"range-article"},r.jsx("h3",null,"Range"),r.jsx("section",null,x.map(((e,t)=>r.jsx("div",{style:{display:"flex"}},r.jsx(d.default,{width:300,domain:m,values:e,onUpdate:e=>b(e,t)}),r.jsx("button",{className:"close-slider wrapper",onClick:()=>function(e){const t=o.default(n,(t=>{const n=t.transform.findIndex((e=>{var t;return"or"in e.filter&&(null===(t=e.filter.or[0])||void 0===t?void 0:t.field)===f&&"range"in e.filter.or[0]}));if(-1===n)return;const i=t.transform[n].filter.or;1===i.length?t.transform.splice(n,1):i.splice(e,1)}));i(t)}(t)},r.jsx(s.X,{size:20}))))),r.jsx("button",{className:"wrapper block add-range",onClick:()=>b(m,x.length)},"+ ",r.jsx(s.Sliders,null)))),r.jsx("section",{className:"transformation-section"},r.jsx("article",{className:"aggregation-article"},r.jsx("h3",null,"Aggregation"),r.jsx("select",{value:g,onChange:t=>e.updateAggregation(t.target.value)},["none",...c.vegaAggregationList].map((e=>r.jsx("option",{value:e},e))))),r.jsx("article",{className:"scaling-article"},r.jsx("h3",null,"Scale"),r.jsx("select",{value:h,onChange:t=>{return r=t.target.value,void i(o.default(n,(t=>{t.encoding[e.encoding].scale={type:r};const n="linear"===r?f:f+` (${r})`;t.encoding[e.encoding].axis?t.encoding[e.encoding].axis.title=n:t.encoding[e.encoding].axis={title:n}})));var r}},c.vegaScaleList.map((e=>r.jsx("option",{value:e},e))))),["x","y"].includes(e.encoding)?r.jsx("article",{className:"binning-article"},r.jsx("h3",null,"Bin"),r.jsx("input",{className:"bin-checkbox",type:"checkbox",onChange:function(t){i(o.default(n,(n=>{n.encoding[e.encoding].bin=t.target.checked})))}})):null))},nominal:function(e){const[t]=l.useModelState("graph_data"),[n,i]=l.useModelState("graph_spec"),{field:o}=n.encoding[e.encoding],s=a.useMemo((()=>p.getCategories(t,o)),[]),c=a.useMemo((function(){var e;const t="oneOf",i=null===(e=n.transform.find((e=>"field"in e.filter&&e.filter.field===o&&t in e.filter)))||void 0===e?void 0:e.filter.oneOf;return new Set(i||new Set(s))}),[n]),d=n.encoding[e.encoding].aggregate;function u(e,t){const r=p.updateSpecFilter(n,o,e,t);i(r)}function f(e){const t=e.target.value;u("oneOf",(n=>n?e.target.checked?[...n,t]:n.filter((e=>e!==t)):Array.from(c).filter((e=>e!==t))))}return r.jsx("div",null,r.jsx("header",{className:"category-header"},r.jsx("h3",null,"Category"),r.jsx("span",{className:"toggle-all",onClick:function(){u("oneOf",(e=>(null==e?void 0:e.length)?[]:s))}},c.size?"Uncheck All":"Check All")),r.jsx("ul",{style:{listStyle:"none"}},s.map((e=>r.jsx("li",{key:e},r.jsx("label",{className:"choice"},r.jsx("input",{type:"checkbox",value:e,checked:c.has(e),onChange:f})," ",e))))),r.jsx("article",{className:"aggregation-article"},r.jsx("h3",null,"Aggregation"),r.jsx("select",{value:d,onChange:t=>e.updateAggregation(t.target.value)},["none","count"].map((e=>r.jsx("option",{value:e},e))))))}},t.default=function(e){const[n,i]=l.useModelState("graph_spec"),a=n.encoding[e.encoding],c=t.filterMap[a.type],{field:d}=n.encoding[e.encoding];return u.default({saveOnDismount:!0,description:`Filtered on ${d}`}),r.jsx("article",{css:f},r.jsx("nav",{className:"filter-nav"},r.jsx("h2",{style:{fontSize:Math.max(35-.7*(e.encoding.length+a.field.length),15)+"px"}},r.jsx("span",{className:"encoding"},e.encoding),": ",r.jsx("span",{className:"column"},a.field)),r.jsx("button",{className:"wrapper",onClick:e.onBack},r.jsx(s.XCircle,null))),r.jsx("div",{className:"filter-contents"},r.jsx(c,{encoding:e.encoding,updateAggregation:function(t){const r=o.default(n,(n=>{n.encoding[e.encoding].aggregate="none"===t?"":t}));i(r)}})))}},4402:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=i(n(7179)),a=n(6271),s=n(6271),l=n(3242),c=i(n(4618)),d=e=>r.css`
  height: 100%;
  .history-list {
    padding: 0;
    max-height: 370px;
    overflow-y: scroll;

    .history-el {
      padding: 10px;
      transition: background-color 0.5s;
      background-color: white;
      border-left: 5px solid ${e.color.primary.standard};
      &:hover {
        background-color: whitesmoke;
      }

      &.active {
        border-left: 5px solid ${e.color.primary.dark};
        font-weight: 700;
      }
    }
  }
`;t.default=function(){const[e,t]=l.useModelState("graph_spec"),[n]=l.useModelState("spec_history"),[i,u]=l.useModelState("current_dataframe_index"),[p,f]=a.useState(""),[g,h]=a.useState([]),m=s.useMemo((()=>[...n].reverse()),[n]),x=s.useMemo((()=>m.map(((e,t)=>`${m.length-t}.   ${e.description||"Graph Changed"}`))),[m]);function b(e){return n.length-1-e}return a.useEffect((()=>{if(!Object.keys(e.encoding).length){const e=o.default(n[n.length-1],(e=>e));t(e)}}),[]),r.jsx("section",{className:"HistoryTab",css:d},r.jsx(c.default,{choices:x,value:p,onChange:f,onResultsChange:h}),r.jsx("ol",{className:"history-list"},g.map((({choice:e,index:n},o)=>{const a=[["history-el",!0],["active",n===b(i)]].filter((e=>e[1])).map((e=>e[0])).join(" ");return r.jsx("li",{className:a,key:n,onClick:()=>function(e){u(b(e)),t(m[e])}(n)},e)}))))}},5911:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(4934),a=i(n(3863)),s=i(n(1867)),l=n(3242),c=i(n(7179)),d=n(6271),u=n(7266),p=i(n(5395)),f=r.css`
  width: 100%;
  height: 100%;

  .chart-list {
    overflow: scroll;
    list-style: none;
    margin: 0;
    padding: 0;
    height: 340px;
    .chart-element {
      padding: 0;
    }
  }

  button {
    background-color: transparent;
    border: 10px solid transparent;
    &:hover {
      border: 10px solid ${p.default.color.primary.light};
    }
  }

  .vega-embed {
    cursor: pointer;
  }
`;function g(e,t){switch(t){case"x":case"y":e.encoding[t].axis={titleColor:"red"};break;case"color":case"size":case"shape":e.encoding[t].legend={titleColor:"red"}}return e}function h(e){return delete e.$schema,delete e.data.url,e.data.name="data",e.transform=[],e.width=120,e.height=120,Object.keys(e.encoding).filter((e=>!["x","y"].includes(e))).forEach((t=>{"bin"in e.encoding[t]&&delete e.encoding[t].bin})),["circle","square"].includes(e.mark)&&(e.mark="point"),e}t.default=function(){const[e,t]=l.useModelState("graph_spec"),n=l.useModelState("graph_data")[0],[i,p]=d.useState([]),[m,x]=d.useState(!0),b={data:n};function v(n){const r=c.default(i[n],(t=>{t.width=e.width,t.height=e.height,t.config={mark:{tooltip:!0}},t.params=[{name:"brush",select:"interval"}],t.transform=e.transform,function(e){for(const t in e.encoding)e.encoding[t].axis?delete e.encoding[t].axis:e.encoding[t].legend&&delete e.encoding[t].legend}(t)}));t(r)}return d.useEffect((()=>{!function(){if("facet"in e.encoding)return void x(!1);const t=o.data2schema(n),i=o.schema2asp(t),r=function(e){const t=Object.assign(Object.assign({},e),{encodings:[]});return c.default(t,(e=>{e.encodings=Object.entries(t.encoding).map((([e,t])=>Object.assign(Object.assign({},t),{channel:e})))}))}(e),s=o.cql2asp(r),l=new a.default;l.init().then((()=>{const t='data("data").\n'+i.concat(s).join("\n"),n=l.solve(t,{models:5}),r=e=>!("facet"in e.encoding||"row"in e.encoding);if(n){const t=n.specs.slice(1).filter(r).map(h).map((t=>function(e,t){const n=new Set(Object.keys(e.encoding)),i=Object.keys(t.encoding).filter((i=>{let r=!0;if(n.delete(i)){const n=e.encoding[i].aggregate!==t.encoding[i].aggregate,o=e.encoding[i].bin!==t.encoding[i].bin;r=n||o}return r}));return i.push(...n),i}(e,t).reduce(g,t)));p(t)}x(!1)}))}()}),[e]),r.jsx("section",{css:f},r.jsx("h2",null,"Find a Similar Chart"),r.jsx("ul",{className:"chart-list"},m?r.jsx("div",{style:{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)"}},r.jsx(s.default,null)):0!==i.length?i.map(((e,t)=>r.jsx("li",{className:"chart-element"},r.jsx("button",{onClick:()=>v(t)},r.jsx(u.VegaLite,{spec:e,data:b,actions:!1}))))):r.jsx("div",null,"No similar charts found")))}},5180:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});const i=n(7593),r=e=>i.css`
  position: relative;

  &:hover > .tooltip {
    display: block;
  }
  .tooltip {
    display: none;
    position: absolute;
    padding: 3px;
    border: 1px solid #e4d2e4;
    border-radius: 3px;
    background: white;
    font-size: 12px;
    pointer-events: none;
    width: max-content;
    max-width: 140px;
    z-index: 200;
    &.top {
      bottom: 100%;
      left: 0;
    }
    &.bottom {
      top: 100%;
      left: 0;
    }
    &.left {
      bottom: 50%;
      right: 100%;
      transform: translateY(50%);
    }
    &.right {
      bottom: 50%;
      left: 100%;
      transform: translateY(50%);
    }
  }
`;t.default=function({message:e,children:t,position:n="top"}){return i.jsx("div",{css:r},t,i.jsx("div",{className:`tooltip ${n}`},e))}},6257:function(e,t,n){"use strict";var i=this&&this.__createBinding||(Object.create?function(e,t,n,i){void 0===i&&(i=n),Object.defineProperty(e,i,{enumerable:!0,get:function(){return t[n]}})}:function(e,t,n,i){void 0===i&&(i=n),e[i]=t[n]}),r=this&&this.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),o=this&&this.__importStar||function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)"default"!==n&&Object.prototype.hasOwnProperty.call(e,n)&&i(t,e,n);return r(t,e),t},a=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const s=n(7593),l=a(n(1141)),c=o(n(6271)),d=a(n(132)),u=a(n(2079)),p=a(n(2071)),f=a(n(5395)),g=n(3242),h=n(6121),m=s.css`
  // Element-based styles
  //===========================================================
  display: grid;
  grid-template-columns: minmax(600px, min-content) minmax(max-content, auto);
  grid-template-rows: 40px auto;
  grid-template-areas: 'nav sidebar' 'graph sidebar';
  height: 100%;

  @media screen and (max-width: 1300px) {
    display: block;
  }

  .side-bar-collapsible-button {
    transition: transform 0.6s ease-in-out;
    transform-origin: 40% 35%;
    cursor: pointer;

    &.open {
      transform: rotate(-270deg);
    }
  }
  .nav-wrapper {
    display: flex;
    justify-content: space-between;
    background: transparent;
  }
`;t.default=function({onPrevious:e}){const t=c.default.useRef(null),n=c.default.useRef(null),[i,r]=c.useState(""),[o,a]=c.useState(!0),[b,v]=c.useState(),[y,j]=c.useState("zoom"),[w,_]=g.useModelState("graph_spec");function k(e){r(e)}function O(){a(!o)}return s.jsx("article",{className:"BifrostWidget",css:m},e?s.jsx(x,{area:"nav"},s.jsx("div",{className:"nav-wrapper"},s.jsx(d.default,{onBack:e,vegaView:b,selection:y,toggleSelection:function(){if("zoom"===y){const e=h.changeSpecProp(w,"params",[{name:"brush",select:"interval"}]);j("brush"),_(e)}else if("brush"===y){const e=h.changeSpecProp(w,"params",[{name:"zoom",select:"interval",bind:"scales"}]);j("zoom"),_(e)}}}),s.jsx("div",{className:"side-bar-collapsible-button"+(o?" open":""),onClick:O},s.jsx(p.default,{color:o?f.default.color.primary.standard:f.default.color.primary.light})))):null,s.jsx(x,{area:"graph",ref:n},s.jsx(u.default,{sideBarRef:t,graphRef:n,clickedAxis:i,updateClickedAxis:k,sideBarOpen:o,clickSidebarButton:O,onViewCreated:v,selection:y})),o?s.jsx(x,{area:"sidebar",ref:t},s.jsx(l.default,{graphRef:n,clickedAxis:i,updateClickedAxis:k})):null)};const x=c.default.forwardRef(((e,t)=>s.jsx("div",{style:{gridArea:e.area},ref:t},e.children)))},1439:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=n(7593),a=n(8589),s=r(n(5395)),l=n(2372),c=n(3773),d=r(n(7288)),u=r(n(6278)),p=n(6271),f=r(n(2608));t.default=function(e){const{onClose:t,position:n,type:r,encoding:g,field:h,filters:m,aggregation:x,scale:b,selectedField:v,onFilterSelected:y,onEncodingSelected:j,onFieldSelected:w}=e,_=i(e,["onClose","position","type","encoding","field","filters","aggregation","scale","selectedField","onFilterSelected","onEncodingSelected","onFieldSelected"]),k=s.default.color.pill[n%s.default.color.pill.length],O=r in l.typeIconMap?l.typeIconMap[r]:d.default,M=r in c.filterIconMap?c.filterIconMap[r]:d.default,S="5px",E=o.css`
    list-style: none;
    background: white;
    border-radius: ${S};
    width: min-content;
    margin: 5px;
    box-shadow: ${s.default.shadow.handle};
    color: ${k.active};

    .pill-header {
      display: flex;
      align-items: stretch;
      justify-content: stretch;
      height: 25px;
      border-radius: 20px;
      background-color: ${k.standard};
      border-radius: ${S} ${S} 0 0;
      overflow: hidden;
      .selected {
        color: white;
        background-color: ${k.active};
      }
      span {
        white-space: nowrap;
        cursor: pointer;
        width: 100%;
        margin: auto 4px;
        text-align: center;

        &:hover {
          text-decoration: underline;
        }
      }

      button {
        width: 100%;
        text-align: center;
        margin: auto 4px;
      }
    }

    .options {
      display: flex;
      align-items: center;
      .slider-button {
        border-radius: 50%;
        background-color: ${k.active};
        padding: 5px;
        margin-left: 3px;
        height: 25px;
        width: 25px;
      }
    }

    .modifiers {
      display: grid;
      grid-template-columns: auto 1fr;
      justify-content: start;
      align-items: center;

      padding: 8px;

      button.icon {
        background-color: transparent;
        transition: background-color 0.3s;
        height: 1em;
        width: 1em;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 4px;
        margin-bottom: -2px;
        &:hover {
          background-color: ${s.default.color.primary.light};
        }
      }

      .filter-list {
        list-style: none;
        padding: 0 5px;
        li {
          margin-bottom: 7px;
          padding: 0;
          white-space: nowrap;
          &:last-child {
            margin-bottom: 0;
          }
        }
      }
    }
  `;return o.jsx("li",Object.assign({className:"graph-pill",css:E},_),o.jsx("div",{className:"pill-header"},o.jsx("button",{className:"wrapper",onClick:e.onFieldTypeSelected},o.jsx(O,{color:k.active})),o.jsx("span",{onClick:j,className:"encoding"===v?"selected":void 0},g),o.jsx("span",{onClick:w,className:"field"===v?"selected":void 0},h),o.jsx("button",{className:"wrapper icon",onClick:t},o.jsx(a.X,{size:15,color:k.active}))),o.jsx("div",{className:"options"},o.jsx("button",{className:"slider-button",onClick:y},o.jsx(a.Sliders,{size:15,color:"white"})),o.jsx("div",{className:"modifiers"},!!m.length&&o.jsx(p.Fragment,null,o.jsx("button",{className:"wrapper icon",onClick:y},o.jsx(M,{size:12,color:k.active})),o.jsx("ul",{className:"filter-list"},m.map(((e,t)=>o.jsx("li",{key:t},e))))),x&&o.jsx(p.Fragment,null,o.jsx("button",{className:"wrapper icon",onClick:e.onFilterSelected},o.jsx(u.default,{color:k.active})),o.jsx("div",{style:{padding:"0 5px"}},x)),b&&o.jsx(p.Fragment,null,o.jsx("button",{className:"wrapper icon",onClick:e.onFilterSelected},o.jsx(f.default,{color:k.active})),o.jsx("div",{style:{padding:"0 5px"}},b)))))}},1867:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});const i=n(7593),r=e=>i.css`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  border: 4px solid ${e.color.primary.light};
  border-right: 4px solid transparent;
  animation: spin 1s infinite;

  @keyframes spin {
    from {
      transform: rotate(0turn);
    }
    to {
      transform: rotate(1turn);
    }
  }
`;t.default=function(e){return i.jsx("div",Object.assign({className:"Loader",css:r},e))}},4296:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});const i=n(7593),r=n(6271),o=i.css`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
`,a=e=>i.css`
  border: 2px solid ${e.color.primary.light};
  border-radius: 5px;
  padding: 25px;
  background: white;
  z-index: 100;
  animation: enter 0.3s ease-out;
  position: absolute;

  @keyframes enter {
    from {
      transform: scale(0.95);
      opacity: 0;
    }
    to {
      transform: scale(1);
      opacity: 1;
    }
  }
`;t.default=function({position:e=[0,0],onBack:t,style:n,children:s}){return i.jsx(r.Fragment,null,i.jsx("div",{className:"backdrop",css:o,onClick:t}),i.jsx("aside",{className:"Modal",css:a,style:Object.assign(Object.assign({},n),{top:e[1],left:e[0]})},s))}},1399:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(3242),a=i(n(4296)),s=r.css`
  list-style: none;
  margin: 0;
  padding: 0;
  font-weight: 600;
  li {
    cursor: pointer;
    margin-bottom: 6px;
    &:last-child {
      margin-bottom: 0;
    }
  }
`;t.default=function({view:e,position:t=[0,0],onBack:n}){const i=o.useModelState("df_code")[0];function l(t){null==e||e.toImageURL(t).then((function(e){const n=document.createElement("a");n.setAttribute("href",e),n.setAttribute("target","_blank"),n.setAttribute("download",`bifrost_chart.${t}`),n.dispatchEvent(new MouseEvent("click"))}))}return r.jsx(a.default,{position:t,onBack:n},r.jsx("ul",{css:s},r.jsx("li",{onClick:()=>{l("png"),n()}},"Export PNG"),r.jsx("li",{onClick:()=>{l("svg"),n()}},"Export SVG"),r.jsx("li",{onClick:()=>{navigator.clipboard.writeText(i),n()}},"Copy Code to Clipboard")))}},2890:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=r.css`
  display: inline-block;
  list-style: none;
  padding: 5px;
  background: #dedede;
  border-radius: 7px;
  border: 1px solid transparent;
  transition: border-color 0.5s;
  width: min-content;
  margin: 7px;

  &:hover {
    border-color: gray;
  }

  .content-wrapper {
    display: flex;
    align-items: center;
  }

  button {
    margin: 0 10px;
  }
`,a=e=>r.css`
  background-color: ${e.color.primary.dark};
  color: white;
  svg {
    color: white;
  }
`;t.default=function(e){var{active:t,children:n,onClick:s}=e,l=i(e,["active","children","onClick"]);return r.jsx("li",Object.assign({css:[o,t&&a],onClick:s},l),r.jsx("div",{className:"content-wrapper"},n))}},7604:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});const i=n(7593),r=n(2430),o=n(6271),a=n(6121),s={position:"relative",width:"100%"};t.default=function({domain:e=[0,100],values:t=[0,20],width:n,onUpdate:o,onSlideEnd:a,vertical:l,reversed:d,onAxis:u}){return i.jsx("div",{className:"RangeSlider"+(u?" onAxis":""),css:i.css`
        width: 100%;
        padding: 12px;
        width: ${n}px;

        &.onAxis {
          input::-webkit-outer-spin-button,
          input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
          }
        }
      `},i.jsx(c,{values:d?[t[1],t[0]]:t,onUpdate:o,reversed:d},i.jsx(r.Slider,{vertical:l,reversed:d,className:"range-slider",mode:1,domain:e,rootStyle:s,onUpdate:o,onSlideEnd:a,values:d?[t[1],t[0]]:t},i.jsx(r.Rail,null,(e=>i.jsx(f,Object.assign({},e)))),i.jsx(r.Handles,null,(({handles:t,getHandleProps:n})=>i.jsx("div",{className:"slider-handles"},t.map((t=>i.jsx(g,{key:t.id,handle:t,domain:e,getHandleProps:n})))))),i.jsx(r.Tracks,{left:!1,right:!1},(({tracks:e,getTrackProps:t})=>i.jsx("div",{className:"slider-tracks"},e.map((({id:e,source:n,target:r})=>i.jsx(h,{key:e,source:n,target:r,getTrackProps:t})))))))))};const l=i.css`
  display: flex;
  width: 100%;
  align-items: center;

  input {
    background-color: transparent;
    border: none;
    width: 5em;
    &.start {
      margin-right: 5px;
    }

    &.end {
      margin-left: 15px;
    }
  }

  .content {
    width: 100%;
  }
`;function c(e){const[t,n]=o.useState(e.values[0]),[r,s]=o.useState(e.values[1]);function c(){let i=t,o=r;t>r&&(o=t,i=r,n(i),s(o)),e.onUpdate([i,o])}function d(e){"Enter"===e.key&&e.target.blur()}return o.useEffect((()=>{n(e.values[0]),s(e.values[1])}),e.values),i.jsx("div",{className:"RangeInputs",css:l},i.jsx("input",{className:"start",value:a.round(t,2),type:"number",name:"min",onChange:e=>n(e.target.valueAsNumber),onBlur:c,onKeyPress:d}),i.jsx("div",{className:"content"},e.children),i.jsx("input",{className:"end",value:a.round(r,2),type:"number",name:"max",onChange:e=>s(e.target.valueAsNumber),onBlur:c,onKeyPress:d}))}function d(e){var t;const n=i.css`
    left: ${e.percent}%;
    position: absolute;
    margin-left: -11px;
    margin-top: -35px;
    padding: 10px;
  `;return i.jsx("div",{className:"Tooltip",css:n},null===(t=e.value)||void 0===t?void 0:t.toFixed(2))}const u=e=>i.css`
  position: absolute;
  width: 100%;
  height: 3px;
  transform: translate(0%, -50%);
  border-radius: 7px;
  cursor: pointer;
  background: ${e.color.primary.light};
`,p=i.css`
  position: absolute;
  width: 100%;
  height: 15px;
  transform: translate(0%, -50%);
  cursor: pointer;
  z-index: 20;
`;function f({activeHandleID:e,getRailProps:t,getEventData:n}){const[r,a]=o.useState({value:null,percent:null}),s=o.useCallback((t=>{a(e?{value:null,percent:null}:n(t))}),[]);return i.jsx(o.Fragment,null,i.jsx(d,Object.assign({},r)),i.jsx("div",Object.assign({className:"tooltip-rail",css:p},t({onMouseEnter:function(){document.addEventListener("mousemove",s)},onMouseLeave:function(){a({value:null,percent:null}),document.removeEventListener("mousemove",s)}}))),i.jsx("div",{className:"rail",css:u}))}function g({domain:[e,t],handle:{id:n,value:r,percent:o},disabled:a=!1,getHandleProps:s}){return i.jsx("div",Object.assign({role:"slider","aria-valuemin":e,"aria-valuemax":t,"aria-valuenow":r,css:e=>i.css`
    left: ${o}%;
    position: absolute;
    transform: translate(-50%, -50%);
    z-index: 2;
    width: 15px;
    height: 15px;

    border-radius: 50%;
    border: 1px solid ${e.color.primary.dark};
    box-shadow: ${e.shadow.handle};
    background-color: ${a?e.color.primary.light:e.color.primary.standard};
  `,className:"handle-2"},s(n)))}function h({source:e,target:t,getTrackProps:n,disabled:r=!1}){return i.jsx("div",Object.assign({className:"track",css:n=>i.css`
        position: absolute;
        transform: translate(0%, -50%);
        height: 7px;
        z-index: 1;
        background-color: ${n.color.primary.light};
        border-radius: 7px;
        cursor: pointer;
        left: ${e.percent}%;
        width: ${t.percent-e.percent}%;
      `},n()))}},4618:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n};Object.defineProperty(t,"__esModule",{value:!0});const r=n(7593),o=n(9850),a=n(6271),s=n(8589),l=r.css`
  height: 23px;
  margin-top: 10px;
  input {
    border: 1px solid #bdbdbd;
    border-radius: 0 20px 20px 0px;
    width: 80%;
    height: 100%;
    margin: 0px;
    margin-left: 35px;
    border-left: none;
    padding: 15px;
    padding-left: 5px;
  }
`,c=r.css`
  position: absolute;
  display: grid;
  place-items: center;
  /* background-color: #eee; */
  width: 30px;
  height: 32px;
  border: 1px solid #bdbdbd;
  border-right: none;
  border-radius: 20px 0 0 20px;
  margin-left: 5px;
  padding-left: 5px;
`;t.default=function(e){const{choices:t,onResultsChange:n,onChange:d,onKeyDown:u,value:p,placeholder:f,forwardedRef:g}=e,h=i(e,["choices","onResultsChange","onChange","onKeyDown","value","placeholder","forwardedRef"]);return a.useEffect((()=>{const e=/[^A-Za-z]/g,i=p.replace(e,"").toLowerCase(),r=t=>{var n;return null===(n=o.StringExt.matchSumOfSquares(t.replace(e,"").toLowerCase(),i))||void 0===n?void 0:n.score},a=t.map(((e,t)=>({choice:e,index:t})));if(0===p.length)n(a);else{const e=a.filter((({choice:e})=>void 0!==r(e)));e.sort(((e,t)=>r(e.choice)-r(t.choice))),n(e)}}),[p,t]),r.jsx("div",{className:"searchBar",css:l},r.jsx("span",{css:c},r.jsx(s.Search,{size:17})),r.jsx("input",Object.assign({ref:g,type:"search",value:p,placeholder:f,onChange:e=>d(e.target.value),onKeyDown:u},h)))}},551:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});const i=n(7593),r=n(2430),o=n(6271),a={position:"relative",width:"100%"};function s(e){const t=i.css`
    left: ${e.percent}%;
    position: absolute;
    margin-left: -11px;
    margin-top: -35px;
    padding: 10px;
  `;return i.jsx("div",{className:"Tooltip",css:t},e.value)}t.default=function({domain:e=[0,100],value:t,width:n,step:o,onUpdate:s,onSlideEnd:l}){return i.jsx("div",{className:"RangeSlider",css:i.css`
        width: 100%;
        padding: 12px;
        width: ${n}px;
      `},i.jsx(r.Slider,{className:"range-slider",mode:1,step:o,domain:e,rootStyle:a,onUpdate:e=>null==s?void 0:s(e[0]),onSlideEnd:e=>null==l?void 0:l(e[0]),values:[t]},i.jsx(r.Rail,null,(e=>i.jsx(d,Object.assign({},e)))),i.jsx(r.Handles,null,(({handles:t,getHandleProps:n})=>i.jsx("div",{className:"slider-handles"},t.map((t=>i.jsx(u,{key:t.id,handle:t,domain:e,getHandleProps:n})))))),i.jsx(r.Tracks,{left:!1,right:!1},(({tracks:e,getTrackProps:t})=>i.jsx("div",{className:"slider-tracks"},e.map((({id:e,source:n,target:r})=>i.jsx(p,{key:e,source:n,target:r,getTrackProps:t}))))))))};const l=e=>i.css`
  position: absolute;
  width: 100%;
  height: 3px;
  transform: translate(0%, -50%);
  border-radius: 7px;
  cursor: pointer;
  background: ${e.color.primary.light};
`,c=i.css`
  position: absolute;
  width: 100%;
  height: 15px;
  transform: translate(0%, -50%);
  cursor: pointer;
  z-index: 20;
`;function d({activeHandleID:e,getRailProps:t,getEventData:n}){const[r,a]=o.useState({value:null,percent:null}),d=o.useCallback((t=>{a(e?{value:null,percent:null}:n(t))}),[]);return i.jsx(o.Fragment,null,i.jsx(s,Object.assign({},r)),i.jsx("div",Object.assign({className:"tooltip-rail",css:c},t({onMouseEnter:function(){document.addEventListener("mousemove",d)},onMouseLeave:function(){a({value:null,percent:null}),document.removeEventListener("mousemove",d)}}))),i.jsx("div",{className:"rail",css:l}))}function u({domain:[e,t],handle:{id:n,value:r,percent:o},disabled:a=!1,getHandleProps:s}){return i.jsx("div",Object.assign({role:"slider","aria-valuemin":e,"aria-valuemax":t,"aria-valuenow":r,css:e=>i.css`
    left: ${o}%;
    position: absolute;
    transform: translate(-50%, -50%);
    z-index: 2;
    width: 15px;
    height: 15px;

    border-radius: 50%;
    border: 1px solid ${e.color.primary.dark};
    box-shadow: ${e.shadow.handle};
    background-color: ${a?e.color.primary.light:e.color.primary.standard};
  `,className:"handle-2"},s(n)))}function p({source:e,target:t,getTrackProps:n,disabled:r=!1}){return i.jsx("div",Object.assign({className:"track",css:n=>i.css`
        position: absolute;
        transform: translate(0%, -50%);
        height: 7px;
        z-index: 1;
        background-color: ${n.color.primary.light};
        border-radius: 7px;
        cursor: pointer;
        left: ${e.percent}%;
        width: ${t.percent-e.percent}%;
      `},n()))}},5909:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.NOOP=void 0,t.NOOP=()=>{}},3242:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.useModel=t.useModelEvent=t.useModelState=t.BifrostModelContext=void 0;const i=n(6271);function r(e,t,n){const r=o(),a=void 0===n?[r]:[...n,r];i.useEffect((()=>{const n=e=>r&&t(r,e);return null==r||r.on(e,n),()=>{null==r||r.unbind(e,n)}}),a)}function o(){return i.useContext(t.BifrostModelContext)}t.BifrostModelContext=i.createContext(void 0),t.useModelState=function(e){const t=o(),[n,a]=i.useState(null==t?void 0:t.get(e));return r(`change:${e}`,(t=>{a(null==t?void 0:t.get(e))}),[e]),[n,function(n,i){null==t||t.set(e,n),null==t||t.save_changes()}]},t.useModelEvent=r,t.useModel=o},7533:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const r=i(n(7179)),o=n(6271),a=i(n(4125)),s=n(3242);t.default=function(e={saveOnDismount:!1,description:""}){const[t,n]=s.useModelState("spec_history"),i=s.useModelState("graph_spec")[0],[l,c]=s.useModelState("current_dataframe_index"),d=s.useModelState("df_code")[1],[u]=s.useModelState("column_name_map"),[p]=s.useModelState("output_variable"),[f]=s.useModelState("df_variable_name"),[g]=s.useModelState("input_url"),[h,m]=o.useState(i),x=o.useRef(b);function b(o=i,s=e.description||"Graph Changed"){const x=h!==o,b=Object.keys(o.encoding).length;if(!x||!b)return;const v=t.slice(0,l+1),y=r.default(o,(e=>{e.description=s}));v.push(y),n(v),c(v.length-1),m(y),d(function(e,t,n,i,o){const s=e=>e.field=o[e.field],l=r.default(e,(e=>{const t=["and","or","not"];e.transform.forEach((({filter:e})=>{const n=Object.keys(e),i=t.find((e=>n.find((t=>e===t))));i?e[i].forEach(s):s(e)}))}));return(new a.default).convertSpecToCode(l,t,n,i)}(y,f,g,p,u))}return o.useEffect((()=>(m(i),()=>{setTimeout((()=>{e.saveOnDismount&&x.current()}),100)})),[]),x.current=b,b}},2763:function(e,t,n){"use strict";var i=this&&this.__rest||function(e,t){var n={};for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&t.indexOf(i)<0&&(n[i]=e[i]);if(null!=e&&"function"==typeof Object.getOwnPropertySymbols){var r=0;for(i=Object.getOwnPropertySymbols(e);r<i.length;r++)t.indexOf(i[r])<0&&Object.prototype.propertyIsEnumerable.call(e,i[r])&&(n[i[r]]=e[i[r]])}return n},r=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});const o=r(n(6271)),a=n(5909),s=n(6121),l=r(n(5097)),c=n(5962),d={};class u extends o.default.PureComponent{constructor(){super(...arguments),this.vegaEmbed=o.default.createRef(),this.handleNewView=e=>{this.update();const{onNewView:t=a.NOOP}=this.props;t(e)}}componentDidMount(){this.update()}componentDidUpdate(e){this.shallowEqual(this.props.data,e.data)||this.update()}shallowEqual(e=d,t=d){const n=Object.keys(e),i=Object.keys(t);return n.length===i.length&&n.every((n=>e[n]===t[n]))}update(){const{data:e}=this.props;this.vegaEmbed.current&&e&&Object.keys(e).length>0&&this.vegaEmbed.current.modifyView((t=>{this.updateMultipleDatasetsInView(t,e),t.resize().run()}))}updateMultipleDatasetsInView(e,t){Object.keys(t).forEach((n=>{this.updateSingleDatasetInView(e,n,t[n])}))}updateSingleDatasetInView(e,t,n){n&&(s.isFunction(n)?n(e.data(t)):e.change(t,c.vega.changeset().remove((()=>!0)).insert(n)))}render(){const e=this.props,{data:t}=e,n=i(e,["data"]);return o.default.createElement(l.default,Object.assign({ref:this.vegaEmbed},n,{onNewView:this.handleNewView,mode:"vega-lite"}))}}t.default=u,u.defaultProps={data:d}},2696:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.vegaTemporalChartList=t.vegaMarkEncodingMap=t.vegaScaleList=t.vegaCategoricalChartList=t.vegaChartList=t.vegaParamPredicatesList=t.vegaAggregationList=t.vegaEncodingList=t.convertToCategoricalChartsEncoding=void 0,t.convertToCategoricalChartsEncoding=function(e,t){"errorband"===t?e.mark={type:t,extent:"ci",borders:!0}:"errorbar"===t?e.mark={type:t,extent:"ci",ticks:!0}:"boxplot"===t&&(delete e.params,e.mark={type:t,extent:"min-max"})},t.vegaEncodingList=["x","y","x2","y2","xError","yError","xError2","yError2","theta","radius","theta2","radius2","longitude","latitude","longitude2","latitude2","color","opacity","fillOpacity","strokeOpacity","strokeWidth","strokeDash","size","angle","shape","text","tooltip","href","description","detail","key","order","facet","row","column"],t.vegaAggregationList=["count","distinct","max","mean","median","min","missing","product","stderr","stdev","stdevp","sum","valid","values","variance","variancep"],t.vegaParamPredicatesList=["equal","lt","lte","gt","gte","range","oneOf","valid"],t.vegaChartList=["bar","boxplot","errorband","errorbar","line","point","tick"],t.vegaCategoricalChartList=["bar","boxplot","errorband","errorbar"],t.vegaScaleList=["linear","log","pow","sqrt"];const n=["x","y","color","opacity","size","facet"];n.sort(),t.vegaMarkEncodingMap={point:n,tick:n,line:n,bar:n,errorband:n,boxplot:n,errorbar:n},t.vegaTemporalChartList=["area"]},5076:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.stringifyFilter=t.getFilterList=t.addDefaultFilter=t.getCategories=t.getBounds=t.deleteSpecFilter=t.updateSpecFilter=void 0;const r=i(n(7179)),o=n(6121),a=n(2696),s=new Set(a.vegaParamPredicatesList);function l(e,t,n,i,a){const s=(null==a?void 0:a.compoundOperator)||"or",[l,d]=c(e,t,n,a),u="range"===n,p=-1!==d;let f;if(o.isFunction(i)){let t;t=u?-1!==l?e.transform[l].filter[s]:[]:e.transform.map((e=>e.filter));const r=p?t[d][n]:null;f=i(r)}else f=i;return r.default(e,(e=>{u?p?e.transform[l].filter[s][d][n]=f:-1!==l?e.transform[l].filter[s].push({field:t,[n]:f}):e.transform.push({filter:{[s]:[{field:t,range:f}]}}):p?e.transform[d].filter[n]=f:e.transform.push({filter:{field:t,[n]:f}})}))}function c(e,t,n,i){const r=(null==i?void 0:i.occurrence)||1,o=(null==i?void 0:i.compoundOperator)||"or";let a,s=-1,l=0,c=-1;"range"===n?(c=e.transform.findIndex((e=>{var i;return o in e.filter&&(null===(i=e.filter[o][0])||void 0===i?void 0:i.field)===t&&n in e.filter[o][0]})),a=-1!==c?e.transform[c].filter[o]:[]):a=e.transform.map((e=>e.filter));for(let e=0;e<a.length;e++){const i=a[e];if(i.field===t&&n in i&&l++,l===r){s=e;break}}return[c,s]}function d(e,t){return e.reduce(((e,n)=>{const i=n[t];return null===i||(e[0]>i&&(e[0]=i),e[1]<i&&(e[1]=i)),e}),[1/0,-1/0])}function u(e,t){const n=e.reduce(((e,n)=>(null===n[t]||e.add(n[t].toString()),e)),new Set);return Array.from(n).sort()}t.updateSpecFilter=l,t.deleteSpecFilter=function(e,t,n,i){const o=(null==i?void 0:i.compoundOperator)||"or",[a,s]=c(e,t,n,i);return-1!==s?r.default(e,(e=>{-1!==a?1===e.transform[a].filter[o].length||(null==i?void 0:i.deleteCompound)?e.transform.splice(a,1):e.transform[a].filter[o].splice(s,1):e.transform.splice(s,1)})):e},t.getBounds=d,t.getCategories=u,t.addDefaultFilter=function(e,t,n,i){return["ordinal","nominal"].includes(n)?l(e,i,"oneOf",u(t,i)):l(e,i,"range",d(t,i))},t.getFilterList=function(e){return e.transform.flatMap((e=>{const t="or"in e.filter?"or":"and"in e.filter?"and":null;return t?e.filter[t]:e.filter}))},t.stringifyFilter=function(e){return Object.keys(e).filter((e=>s.has(e))).map((t=>{let n;switch(t){case"gte":return"> "+e.gte.toFixed(2);case"lte":return"< "+e.lte.toFixed(2);case"range":return`${e.range[0].toFixed(2)} - ${e.range[1].toFixed(2)}`;case"oneOf":return n=e.oneOf.join(", "),n.length>20?n.slice(0,20)+"...":n;default:return""}}))}},4125:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});const i=n(2696),r=n(6121),o=new Set(i.vegaParamPredicatesList),a={count:"count",valid:(e,t)=>`${t}.join(${t}.dropna().groupby(group_fields).count()["${e.field}"], on=group_fields, rsuffix=" valid count")`,missing:(e,t)=>`${t}.join(${t}.groupby(group_fields)["${e.field}"].apply(lambda x: x.isnull().sum()), on=group_fields, rsuffix=" missing")`,distinct:(e,t)=>`${t}.join(${t}.dropna().groupby(group_fields)["${e.field}"].unique(), on=group_fields, rsuffix=" distinct")`,sum:"sum",product:"prod",mean:"mean",variance:"var",variancep:(e,t)=>`${t}.join(${t}.groupby(group_fields).var(ddof=0)["${e.field}"], on=group_fields, rsuffix=" population variance")`,stdev:"std",stdevp:(e,t)=>`${t}.join(${t}.groupby(group_fields).std(ddof=0)["${e.field}"], on=group_fields, rsuffix=" population std")`,stderr:(e,t)=>`${t}.join(${t}.groupby(group_fields).sem()["${e.field}"], on=group_fields, rsuffix=" stderr")`,median:"median",min:"min",max:"max"};t.default=class{getQueryFromFilter(e,t){return Object.keys(e).filter((e=>o.has(e))).map((n=>{let i;switch(n){case"gte":i=`(${t}['${e.field}'] >= ${e.gte})`;break;case"lte":i=`(${t}['${e.field}'] <= ${e.lte})`;break;case"range":i=`(${t}['${e.field}'] >= ${e.range[0]}) & (${t}['${e.field}'] <= ${e.range[1]})`;break;case"oneOf":i=`(${t}['${e.field}'].isin([${e.oneOf.map((e=>`"${e}"`)).toString()}]))`;break;default:i=""}return i})).join("&")}getFilterFromTransform(e,t){return e.map((e=>{const n="or"in e.filter?"or":"and"in e.filter?"and":null;if(n){const i="or"===n?"|":"&",r=e.filter[n].map((e=>this.getQueryFromFilter(e,t)));let o=r.join(i);return r.length>1&&(o="("+o+")"),o}return this.getQueryFromFilter(e.filter,t)})).join("&")}getAggregations(e,t){const n=Object.values(e);return n.filter((e=>"aggregate"in e)).map((e=>{const i=a[e.aggregate],o=`group_fields = [${n.filter((t=>t!==e)).map((e=>`"${e.field}"`)).toString()}]`;return"string"==typeof i?[o,`${t} = ${t}.join(${t}.groupby(group_fields).agg("${i}")["${e.field}"], on=group_fields, rsuffix=" ${i}")`].join("\n"):r.isFunction(i)?[o,`${t} = ${i(e,t)}`].join("\n"):""})).join("\n")}getBinning(e,t){return Object.values(e).filter((e=>e.bin)).map((({field:e})=>{const n=`${t}["${e}"]`;return`_bifrost_bins = pd.cut(${n}, bins=pd.interval_range(start=${n}.min(), freq=10, end=${n}.max())).rename("${e} (bin)")\n${t} = pd.concat((${t}, _bifrost_bins), axis=1)\n        `})).join("\n")}getAxisScaling(e,t){const n=Object.values(e).filter((e=>"scale"in e&&e.scale.type&&"linear"!==e.scale.type)).map((e=>{const t=e.field,n=e.scale.type,i=`${t} (${n})`;let r="";switch(n){case"log":r=`np.log(df["${t}"])`;break;case"pow":r=`np.exp(df["${t}"])`;break;case"sqrt":r=`np.sqrt(df["${t}"])`}return`${r}.rename("${i}")`})).join(",");return n.length?`${t} = pd.concat((${t}, ${n}), axis=1)`:""}convertSpecToCode(e,t="",n="",i=""){const r=[],o=t||"temp";t||r.push(`temp = pd.read_csv('${n}')`);const a=this.getFilterFromTransform(e.transform,o),s=a.length?i?`${i} = ${o}[${a}]`:`${o}[${a}]`:"";s&&r.push(s);const l=this.getAggregations(e.encoding,i);l&&r.push(l);const c=this.getAxisScaling(e.encoding,i);c&&r.push(c);const d=this.getBinning(e.encoding,i);d&&r.push(d);const u=r.join("\n");return/\w/.test(u)?u:t}}},6121:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.changeSpecProp=t.round=t.hasDuplicateField=t.isFunction=void 0;const r=i(n(7179));t.isFunction=e=>e&&"[object Function]"==={}.toString.call(e),t.hasDuplicateField=function(e,t){return Object.values(e.encoding).filter((e=>e.field===t)).length>1},t.round=function(e,t){const n=Math.pow(10,t);return Math.floor(n*e)/n},t.changeSpecProp=function(e,t,n){return r.default(e,(e=>{e[t]=n}))}},5395:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default={color:{text:["#000"],background:["#fff","#F6F6F6"],primary:{dark:"#771C79",standard:"#AD77AF",light:"#E4D2E4"},pill:[{standard:"#F3E5DA",active:"#A84822"},{standard:"#E0EEF3",active:"#1A5B71"},{standard:"#E7EFE3",active:"#517242"},{standard:"#E5E4F0",active:"#4B3E98"},{standard:"#F4E6E7",active:"#9E1C3C"}]},shadow:{handle:"0 0 10px #781c7932"}}},8657:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.MODULE_NAME=t.MODULE_VERSION=void 0;const i=n(4147);t.MODULE_VERSION=i.version,t.MODULE_NAME=i.name},1367:function(e,t,n){"use strict";var i=this&&this.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0}),t.BifrostView=t.BifrostModel=void 0;const r=n(2565),o=i(n(6271)),a=i(n(4456)),s=i(n(200)),l=n(8657);n(7204);const c={spec_history:[],output_variable:"",df_variable_name:"",current_dataframe_index:0,graph_spec:{},query_spec:{},df_columns:[],df_column_ranges:{},selected_data:["",{}],selected_columns:[],passed_kind:"",graph_data:{},graph_bounds:{},suggested_graphs:[],flags:{},passed_encodings:{},column_types:{},column_name_map:{},graph_data_config:{sampleSize:100,datasetLength:1},df_code:"$df",input_url:""};class d extends r.DOMWidgetModel{defaults(){return Object.assign(Object.assign(Object.assign({},super.defaults()),{_model_name:d.model_name,_model_module:d.model_module,_model_module_version:d.model_module_version,_view_name:d.view_name,_view_module:d.view_module,_view_module_version:d.view_module_version}),c)}}t.BifrostModel=d,d.serializers=Object.assign({},r.DOMWidgetModel.serializers),d.model_name="BifrostModel",d.model_module=l.MODULE_NAME,d.model_module_version=l.MODULE_VERSION,d.view_name="BifrostView",d.view_module=l.MODULE_NAME,d.view_module_version=l.MODULE_VERSION;class u extends r.DOMWidgetView{render(){this.el.classList.add("bifrost-widget");const e=o.default.createElement(s.default,{model:this.model});a.default.render(e,this.el)}}t.BifrostView=u},3889:(e,t,n)=>{(t=n(3645)(!1)).push([e.id,".bifrost-widget {\n  position: relative;\n  box-sizing: border-box;\n  max-width: 100%;\n}\n",""]),e.exports=t},7204:(e,t,n)=>{var i=n(3379),r=n(3889);"string"==typeof(r=r.__esModule?r.default:r)&&(r=[[e.id,r,""]]);i(r,{insert:"head",singleton:!1}),e.exports=r.locals||{}},4147:e=>{"use strict";e.exports=JSON.parse('{"name":"jupyter_bifrost","version":"0.2.0","description":"A Jupyter Widget for Interactive Data Visualization","keywords":["jupyter","jupyterlab","jupyterlab-extension","widgets"],"files":["lib/**/*.js","dist/*.js","css/*.css"],"homepage":"https://github.com//jupyter_bifrost","bugs":{"url":"https://github.com//jupyter_bifrost/issues"},"license":"BSD-3-Clause","author":{"name":"John Waidhofer(waidhoferj), Jay Ahn(jahn96)","email":"waidhoferj@gmail.com, aju960219@gmail.com"},"main":"lib/index.js","types":"./lib/index.d.ts","repository":{"type":"git","url":"https://github.com//jupyter_bifrost"},"scripts":{"build":"yarn run build:lib && yarn run build:nbextension && yarn run build:labextension:dev","build:prod":"yarn run build:lib && yarn run build:labextension","build:binder":"yarn run build:lib && yarn run build:labextension","build:labextension":"jupyter labextension build .","build:labextension:dev":"jupyter labextension build --development True .","build:lib":"tsc","build:nbextension":"webpack","clean":"yarn run clean:lib && yarn run clean:nbextension && yarn run clean:labextension","clean:lib":"rimraf lib","clean:labextension":"rimraf jupyter_bifrost/labextension","clean:nbextension":"rimraf jupyter_bifrost/nbextension/static/index.js","lint":"eslint . --ext .ts,.tsx --fix","lint:check":"eslint . --ext .ts,.tsx","prepack":"yarn run build:lib","test":"jest","watch":"npm-run-all -p watch:*","watch:lib":"tsc -w","watch:nbextension":"webpack --watch --mode=development","watch:labextension":"jupyter labextension watch .","prepare":"jlpm run clean && jlpm run build:prod"},"dependencies":{"@emotion/react":"^11.4.0","@jupyter-widgets/base":"^1.1.10 || ^2.0.0 || ^3.0.0 || ^4.0.0","@jupyterlab/application":"^3.0.11","@types/debounce":"^1.2.0","@types/react-dom":"^17.0.8","@types/react-transition-group":"^1.1.7","compassql":"^0.21.2","debounce":"^1.2.1","draco-core":"^0.0.6","draco-vis":"^0.0.16","husky":"^6.0.0","immer":"^9.0.3","react":"^17.0.2","react-compound-slider":"^3.3.1","react-dom":"^17.0.2","react-feather":"^2.0.9","react-markdown":"6.0.3","react-transition-group":"1.2","react-vega":"^7.4.3","vega":"^5.20.2","vega-embed":"^6.18.2","vega-lite":"^5.1.0","vega-lite-api":"^5.0.0"},"devDependencies":{"@babel/core":"^7.5.0","@babel/preset-env":"^7.5.0","@babel/preset-react":"^7.14.5","@babel/preset-typescript":"^7.14.5","@jupyterlab/builder":"^3.0.0","@phosphor/application":"^1.6.0","@phosphor/widgets":"^1.6.0","@testing-library/jest-dom":"^5.14.1","@testing-library/react":"^12.0.0","@types/jest":"^26.0.0","@types/node":"^15.12.2","@types/react":"^17.0.11","@types/react-tag-input":"^6.1.2","@types/webpack-env":"^1.13.6","@typescript-eslint/eslint-plugin":"^3.6.0","@typescript-eslint/parser":"^3.6.0","acorn":"^7.2.0","babel-loader":"^8.2.2","babel-preset-es2015":"^6.24.1","canvas":"^2.8.0","css-loader":"^3.2.0","eslint":"^7.4.0","eslint-config-prettier":"^6.11.0","eslint-plugin-prettier":"^3.1.4","fs-extra":"^7.0.0","husky":"^6.0.0","identity-obj-proxy":"^3.0.0","jest":"^26.0.0","lint-staged":"^11.0.0","mkdirp":"^0.5.1","npm-run-all":"^4.1.5","prettier":"^2.0.5","rimraf":"^2.6.2","sass":"^1.35.1","sass-loader":"^12.1.0","source-map-loader":"^1.1.3","style-loader":"^1.0.0","ts-jest":"^26.0.0","ts-loader":"^8.0.0","typescript":"~4.1.3","webpack":"^5.0.0","webpack-cli":"^4.0.0"},"babel":{"presets":["@babel/preset-env","@babel/preset-react","@babel/preset-typescript"]},"lint-staged":{"src/**/*.{js,jsx,ts,tsx}":["eslint --cache --fix"]},"jupyterlab":{"extension":"lib/plugin","outputDir":"jupyter_bifrost/labextension/","sharedPackages":{"@jupyter-widgets/base":{"bundled":false,"singleton":true}}}}')}}]);