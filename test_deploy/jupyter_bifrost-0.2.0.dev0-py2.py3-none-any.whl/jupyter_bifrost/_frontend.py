#!/usr/bin/env python
# coding: utf-8

# Copyright (c) John Waidhofer(waidhoferj), Jay Ahn(jahn96).
# Distributed under the terms of the Modified BSD License.

"""
Information about the frontend package of the widgets.
"""

module_name = "jupyter_bifrost"
module_version = "^0.1.0"
